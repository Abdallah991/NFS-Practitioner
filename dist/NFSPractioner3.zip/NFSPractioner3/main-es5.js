(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
    /***/
    0:
    /*!***************************!*\
      !*** multi ./src/main.ts ***!
      \***************************/

    /*! no static exports found */

    /***/
    function _(module, exports, __webpack_require__) {
      module.exports = __webpack_require__(
      /*! /Users/abdullaaljalahma/Documents/GitHubKaraken/NFS-Practitioner/src/main.ts */
      "zUnb");
      /***/
    },

    /***/
    1:
    /*!********************!*\
      !*** fs (ignored) ***!
      \********************/

    /*! no static exports found */

    /***/
    function _(module, exports) {
      /* (ignored) */

      /***/
    },

    /***/
    2:
    /*!**********************!*\
      !*** path (ignored) ***!
      \**********************/

    /*! no static exports found */

    /***/
    function _(module, exports) {
      /* (ignored) */

      /***/
    },

    /***/
    "2aaj":
    /*!**********************************************!*\
      !*** ./src/app/services/dropzone.service.ts ***!
      \**********************************************/

    /*! exports provided: DropzoneService */

    /***/
    function aaj(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "DropzoneService", function () {
        return DropzoneService;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var DropzoneService = function DropzoneService() {
        _classCallCheck(this, DropzoneService);
      };

      DropzoneService.ɵfac = function DropzoneService_Factory(t) {
        return new (t || DropzoneService)();
      };

      DropzoneService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
        token: DropzoneService,
        factory: DropzoneService.ɵfac,
        providedIn: 'root'
      });
      /***/
    },

    /***/
    3:
    /*!********************!*\
      !*** fs (ignored) ***!
      \********************/

    /*! no static exports found */

    /***/
    function _(module, exports) {
      /* (ignored) */

      /***/
    },

    /***/
    "95/t":
    /*!**********************************************************************************!*\
      !*** ./src/app/screens/register-practitioner/register-practitioner.component.ts ***!
      \**********************************************************************************/

    /*! exports provided: RegisterPractitionerComponent */

    /***/
    function t(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RegisterPractitionerComponent", function () {
        return RegisterPractitionerComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _sendgrid_mail__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @sendgrid/mail */
      "EOyl");
      /* harmony import */


      var _sendgrid_mail__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_sendgrid_mail__WEBPACK_IMPORTED_MODULE_2__);
      /* harmony import */


      var src_app_constants_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! src/app/constants/constants */
      "bl9C");
      /* harmony import */


      var src_app_constants_specialties__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/constants/specialties */
      "SZuB");
      /* harmony import */


      var src_app_components_location_picker_location_picker_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! src/app/components/location-picker/location-picker.component */
      "bY5k");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var src_app_services_dropzone_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! src/app/services/dropzone.service */
      "2aaj");
      /* harmony import */


      var src_app_services_practitioner_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! src/app/services/practitioner.service */
      "mqhL");
      /* harmony import */


      var src_app_app_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! src/app/app.component */
      "Sy1n");
      /* harmony import */


      var _agm_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @agm/core */
      "pxUr");
      /* harmony import */


      var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @angular/material/dialog */
      "0IaG");
      /* harmony import */


      var _drop_zone_drop_zone_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! ../../drop-zone/drop-zone.component */
      "9Gt3");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");

      var _c0 = ["search"];

      function RegisterPractitionerComponent_option_16_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "option");

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var title_r10 = ctx.$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", title_r10, " ");
        }
      }

      function RegisterPractitionerComponent_div_34_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 44);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "label");

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](2, "input", 45);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var gender_r11 = ctx.$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate"]("value", gender_r11);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", gender_r11, " ");
        }
      }

      function RegisterPractitionerComponent_option_48_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "option", 46);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var countrycode_r12 = ctx.$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate"]("value", countrycode_r12.code);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", countrycode_r12.name, " ");
        }
      }

      function RegisterPractitionerComponent_option_58_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "option", 46);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var speciality_r13 = ctx.$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate"]("value", speciality_r13);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", speciality_r13, " ");
        }
      }

      function RegisterPractitionerComponent_div_60_option_5_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "option", 46);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var subCategory_r15 = ctx.$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate"]("value", subCategory_r15);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", subCategory_r15, " ");
        }
      }

      function RegisterPractitionerComponent_div_60_Template(rf, ctx) {
        if (rf & 1) {
          var _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div");

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "label");

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](2, "Sub-Categories");

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](3, "br");

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "select", 47);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("change", function RegisterPractitionerComponent_div_60_Template_select_change_4_listener($event) {
            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r17);

            var ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();

            return ctx_r16.changeSubCategory($event);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](5, RegisterPractitionerComponent_div_60_option_5_Template, 2, 2, "option", 20);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx_r4.subCategories);
        }
      }

      function RegisterPractitionerComponent_option_100_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "option", 46);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var language_r18 = ctx.$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate"]("value", language_r18);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", language_r18, " ");
        }
      }

      function RegisterPractitionerComponent_div_108_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 48);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](1, "img", 49);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "p");

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var name_r19 = ctx.$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](name_r19);
        }
      }

      function RegisterPractitionerComponent_div_120_Template(rf, ctx) {
        if (rf & 1) {
          var _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 50);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function RegisterPractitionerComponent_div_120_Template_div_click_0_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r21);

            var ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();

            return ctx_r20.openLocationDialog();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        }
      }

      function RegisterPractitionerComponent_div_121_Template(rf, ctx) {
        if (rf & 1) {
          var _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 51);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function RegisterPractitionerComponent_div_121_Template_div_click_0_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r23);

            var ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();

            return ctx_r22.openLocationDialog();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        }
      }

      var RegisterPractitionerComponent = /*#__PURE__*/function () {
        function RegisterPractitionerComponent(fb, DrS, PS, appComponent, mapsAPILoader, ngZone, dialog, http, practitionerService) {
          _classCallCheck(this, RegisterPractitionerComponent);

          this.fb = fb;
          this.DrS = DrS;
          this.PS = PS;
          this.appComponent = appComponent;
          this.mapsAPILoader = mapsAPILoader;
          this.ngZone = ngZone;
          this.dialog = dialog;
          this.http = http;
          this.practitionerService = practitionerService; //patterns for input validation

          this.stringPattern = "[a-zA-Z ]*";
          this.numberPattern = /\-?\d*\.?\d{1,2}/;
          this.emailPattern = /(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9]))\.){3}(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9])|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])/; //  urls for certifications

          this.urls = []; //  certifications file names

          this.fileNames = [];
          this.attachements = [];
          this.submitted = false; //  drop downs content

          this.titles = src_app_constants_constants__WEBPACK_IMPORTED_MODULE_3__["TITLES"];
          this.genders = src_app_constants_constants__WEBPACK_IMPORTED_MODULE_3__["GENDERS"];
          this.countryCodes = src_app_constants_constants__WEBPACK_IMPORTED_MODULE_3__["COUNTRY_CODES"];
          this.specialties = src_app_constants_specialties__WEBPACK_IMPORTED_MODULE_4__["SPECIALTIES"];
          this.subCategories = src_app_constants_specialties__WEBPACK_IMPORTED_MODULE_4__["SUB_CATEGORIES_ALTERNATIVE"];
          this.showSubCategories = false;
          this.Languages = src_app_constants_constants__WEBPACK_IMPORTED_MODULE_3__["LANGUAGES"];
          this.filesAvailable = false; // Send Grid code

          this.sgMail = __webpack_require__(
          /*! @sendgrid/mail */
          "EOyl");
          this.fs = __webpack_require__(
          /*! fs */
          3);
          this.lat = 0;
        }

        _createClass(RegisterPractitionerComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      this.DrS.image = "";
                      this.DrS.size = "150px"; //  form group initialization
                      // testing API calls
                      //  let httpcall = await this.http.get('https://www.passwordrandom.com/query?command=password').subscribe(val => {
                      //   console.log(val, 'this is the resposne ');
                      //  });
                      //  console.log(httpcall, 'this is the resposne ');

                      this.registerPractitioner = this.fb.group({
                        specialty: [this.specialties[0], [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required]],
                        firstName: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].pattern(this.stringPattern)]),
                        lastName: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].pattern(this.stringPattern)]),
                        email: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].pattern(this.emailPattern)]),
                        phone: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].pattern(this.numberPattern)]),
                        locationName: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](""),
                        gender: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](this.genders[0], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required),
                        experience: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required]),
                        about: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required]),
                        education: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required]),
                        pricePerSession: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].pattern(this.numberPattern)]),
                        title: [this.titles[0], [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required]],
                        countryCode: [this.countryCodes[0], [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required]],
                        languages: [this.Languages[0], [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required]],
                        subCategory: [""]
                      });

                    case 3:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          } // getters for from

        }, {
          key: "title",
          get: function get() {
            return this.registerPractitioner.get("title");
          }
        }, {
          key: "firstName",
          get: function get() {
            return this.registerPractitioner.get("firstName");
          }
        }, {
          key: "lastName",
          get: function get() {
            return this.registerPractitioner.get("lastName");
          }
        }, {
          key: "email",
          get: function get() {
            return this.registerPractitioner.get("email");
          }
        }, {
          key: "gender",
          get: function get() {
            return this.registerPractitioner.get("gender");
          }
        }, {
          key: "phone",
          get: function get() {
            return this.registerPractitioner.get("phone");
          }
        }, {
          key: "countryCode",
          get: function get() {
            return this.registerPractitioner.get("countryCode");
          }
        }, {
          key: "locationName",
          get: function get() {
            return this.registerPractitioner.get("locationName");
          }
        }, {
          key: "experience",
          get: function get() {
            return this.registerPractitioner.get("experience");
          }
        }, {
          key: "about",
          get: function get() {
            return this.registerPractitioner.get("about");
          }
        }, {
          key: "education",
          get: function get() {
            return this.registerPractitioner.get("education");
          }
        }, {
          key: "pricePerSession",
          get: function get() {
            return this.registerPractitioner.get("pricePerSession");
          }
        }, {
          key: "subCategory",
          get: function get() {
            return this.registerPractitioner.get("subCategory");
          }
        }, {
          key: "specialty",
          get: function get() {
            return this.registerPractitioner.get("specialty");
          }
        }, {
          key: "languages",
          get: function get() {
            return this.registerPractitioner.get("languages");
          }
        }, {
          key: "submitHandler",
          value: function submitHandler() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2);
            }));
          } // submit button implementation

          /**
           * @module checkout
           * @author Abdallah Alathamneh
           * @description Adding the information needed to complete the orders (address, date, time, payment method)
           * Payment integration
           * sending the order to the backend
           * @date 24/12/2020
           * @version 1.0.0
           * @date 26/04/2021
           * @version 2.0.0
           */

        }, {
          key: "onSubmit",
          value: function onSubmit() {
            console.log("The button was clicked onsubmit", this.registerPractitioner.value);
            this.submitted = true;
            this.loadApplicantData(); // log out the form and if its valid

            console.log(this.registerPractitioner.value, this.registerPractitioner.valid);

            if (this.registerPractitioner.valid) {
              this.PS.uploadApplicant();
              console.log("The button was clicked onhandler");
            } else {
              this.appComponent.openFailureSnackBar("Please fill the missing information");
            }

            this.sendEmail(this.attachements);
          } // upload practitioner image

        }, {
          key: "setfile",
          value: function setfile(event) {
            this.PS.file = event;
            console.log(this.PS.file);
            console.log(event);
            this.filesAvailable = true;
            console.log(this.filesAvailable);
          } // upload certificates

        }, {
          key: "selectFiles",
          value: function selectFiles(event) {
            var _this = this;

            console.log(event.target.files.length);

            if (event.target.files) {
              var _loop = function _loop(i) {
                reader = new FileReader();
                reader.readAsDataURL(event.target.files[i]);

                _this.fileNames.push(event.target.files[i].name);

                var name = event.target.files[i].name;

                reader.onload = function (event) {
                  _this.urls.push(event.target.result);

                  var attch = event.target.result;

                  _this.attachements.push({
                    content: attch.replace(/^data:application\/pdf;base64,/, ""),
                    filename: name,
                    type: "application/pdf",
                    disposition: "attachment"
                  });
                };
              };

              for (var i = 0; i < event.target.files.length; i++) {
                var reader;

                _loop(i);
              }

              console.log(this.attachements);
              setTimeout(function () {
                return _this.sendEmail(_this.attachements);
              }, 5000);
              console.log(this.fileNames);
            } // calling the cloud function from the app


            var url = "https://us-central1-nhsc-edd5c.cloudfunctions.net/proceedOrder";
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpHeaders"]({
              "Content-Type": "application/json",
              "Access-Control-Allow-Origin": "*"
            });
            this.http.post("https://us-central1-nfsapp-390d4.cloudfunctions.net/sendCertificates", {
              data: "test"
            }, {
              headers: headers
            }).subscribe(function (data) {
              console.log("data", data);
            });
          } // select title

        }, {
          key: "changeTitle",
          value: function changeTitle(e) {
            this.title.setValue(e.target.value, {
              onlySelf: true
            });
          } // select country code

        }, {
          key: "changeCountryCode",
          value: function changeCountryCode(e) {
            console.log(e.target.value);
            this.countryCode.setValue(e.target.value, {
              onlySelf: true
            });
          } // select specialty

        }, {
          key: "changeSpecialty",
          value: function changeSpecialty(e) {
            this.specialty.setValue(e.target.value, {
              onlySelf: true
            });
            console.log(e.target.value);

            switch (e.target.value) {
              case src_app_constants_specialties__WEBPACK_IMPORTED_MODULE_4__["SPECIALTIES"][2]:
                this.subCategories = src_app_constants_specialties__WEBPACK_IMPORTED_MODULE_4__["SUB_CATEGORIES_BEHAVRIORAL"];
                this.showSubCategories = true;
                break;

              case src_app_constants_specialties__WEBPACK_IMPORTED_MODULE_4__["SPECIALTIES"][3]:
                this.subCategories = src_app_constants_specialties__WEBPACK_IMPORTED_MODULE_4__["SUB_CATEGORIES_ALTERNATIVE"];
                this.showSubCategories = true;
                break;

              default:
                this.showSubCategories = false;
                break;
            }
          } //  select sub-category

        }, {
          key: "changeSubCategory",
          value: function changeSubCategory(e) {
            this.subCategory.setValue(e.target.value, {
              onlySelf: true
            });
          } //  select language

        }, {
          key: "changeLanguage",
          value: function changeLanguage(e) {
            this.languages.setValue(e.target.value, {
              onlySelf: true
            });
          } // upload applicant data into the service

        }, {
          key: "loadApplicantData",
          value: function loadApplicantData() {
            this.PS.title = this.title.value;
            this.PS.practitionerFirstName = this.firstName.value;
            this.PS.practitionerLastName = this.lastName.value;
            this.PS.gender = this.gender.value;
            this.PS.email = this.email.value;
            this.PS.phone = this.phone.value;
            this.PS.countryCode = this.countryCode.value;
            this.PS.specialty = this.specialty.value;
            this.PS.subCategory = this.subCategory.value;
            this.PS.about = this.about.value;
            this.PS.education = this.education.value;
            this.PS.experience = this.experience.value;
            this.PS.pricePerSession = this.pricePerSession.value;
            this.PS.languages = this.languages.value;
            this.PS.locationName = this.locationName.value;
            this.PS.certificateNames = this.fileNames;
          } // send email implementation

        }, {
          key: "sendEmail",
          value: function sendEmail(attachements) {
            // body of the message
            var htmlSendEmail = "<h3> Hello NFS team,</h3>" + "<br>" + "<p> Please find my certificates attaches below</p>"; // subject and sender email

            var subject = "Certificates and licenses for " + this.title.value + " " + this.firstName.value + " " + this.lastName.value;
            var senderEmail = this.email.value;
            this.msg = {
              to: "abdallah@fthm.me",
              from: "abdallah@fthm.me",
              subject: "test",
              text: "body",
              html: "<h1> this is a test</h1>",
              attachments: attachements
            };
            this.sgMail = _sendgrid_mail__WEBPACK_IMPORTED_MODULE_2__["setApiKey"]("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"); // send gird send email code
            // this.sgMail
            //   .send(this.msg)
            //   .then((response) => {
            //     console.log(response);
            //     console.log("the header are", response[0].headers);
            //   })
            //   .catch((error) => {
            //     // console.error(error);
            //   });
          }
        }, {
          key: "openLocationDialog",
          value: function openLocationDialog() {
            var _this2 = this;

            this.dialog.open(src_app_components_location_picker_location_picker_component__WEBPACK_IMPORTED_MODULE_5__["LocationPickerComponent"], {
              maxHeight: "90vh",
              width: "80vw",
              maxWidth: "700px"
            }).afterClosed().subscribe(function () {
              _this2.lat = _this2.practitionerService.lat;
            });
          }
        }, {
          key: "loadAttachements",
          value: function loadAttachements() {}
        }]);

        return RegisterPractitionerComponent;
      }();

      RegisterPractitionerComponent.ɵfac = function RegisterPractitionerComponent_Factory(t) {
        return new (t || RegisterPractitionerComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_services_dropzone_service__WEBPACK_IMPORTED_MODULE_8__["DropzoneService"]), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_services_practitioner_service__WEBPACK_IMPORTED_MODULE_9__["PractitionerService"]), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_app_component__WEBPACK_IMPORTED_MODULE_10__["AppComponent"]), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_agm_core__WEBPACK_IMPORTED_MODULE_11__["MapsAPILoader"]), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["NgZone"]), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_12__["MatDialog"]), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_services_practitioner_service__WEBPACK_IMPORTED_MODULE_9__["PractitionerService"]));
      };

      RegisterPractitionerComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
        type: RegisterPractitionerComponent,
        selectors: [["app-register-practitioner"]],
        viewQuery: function RegisterPractitionerComponent_Query(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵviewQuery"](_c0, 1);
          }

          if (rf & 2) {
            var _t;

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵloadQuery"]()) && (ctx.searchElementRef = _t.first);
          }
        },
        decls: 137,
        vars: 11,
        consts: [[1, "page-container"], [1, "sidebox"], [3, "formGroup", "ngSubmit"], [1, "center-align"], [1, "top-view"], [1, "uploadfilecontainer"], [3, "fileEmmitor"], [1, "top-fields"], ["formControlName", "title", 1, "selectbox", "textbox-top", 3, "change"], [4, "ngFor", "ngForOf"], ["type", "text", "name", "firstName", "formControlName", "firstName", "required", "", 1, "textbox-top"], ["for", "fname"], ["type", "text", "name", "lastName", "formControlName", "lastName", 1, "textbox-top"], ["for", "Gender"], ["class", "gender-selection", 4, "ngFor", "ngForOf"], [1, "bottom-fields"], ["type", "email", "name", "Email", "formControlName", "email", 1, "textbox-bottom"], [1, "phone-container"], [1, "country-code"], ["name", "countryCode", 1, "selectbox", "textbox-bottom", 3, "change"], [3, "value", 4, "ngFor", "ngForOf"], [1, "phone-number"], ["type", "number", "name", "Email", "formControlName", "phone", 1, "textbox-bottom"], ["formControlName", "specialty", 1, "selectbox", "textbox-bottom", 3, "change"], [4, "ngIf"], [1, "input-note"], ["rows", "3", "formControlName", "experience", "maxlength", "500", 1, "largetextbox"], ["rows", "3", "formControlName", "about", "maxlength", "500", 1, "largetextbox"], ["rows", "3", "formControlName", "education", "maxlength", "500", 1, "largetextbox"], ["type", "number", "name", "pricePerSession", "formControlName", "pricePerSession", 1, "textbox-bottom"], ["name", "languages", "formControlName", "languages", 1, "selectbox", "textbox-bottom", 3, "change"], [1, "uploadfilecontainer2", 3, "click"], ["type", "file", "multiple", "", "hidden", "", 3, "change"], ["fileInput", ""], ["class", "file-list", 4, "ngFor", "ngForOf"], ["type", "text", "formControlName", "locationName", 1, "textbox-bottom"], ["class", "location-container", 3, "click", 4, "ngIf"], ["class", "location-container-complete", 3, "click", 4, "ngIf"], [1, "terms-conditions"], ["type", "checkbox", "name", "terms", 1, "terms-checkbox"], ["href", "https://www.nfsapp.online/legal/", "target", "_blank"], [1, "terms-link"], ["type", "submit", 1, "button", 3, "disabled", "click"], [1, "page-content-container"], [1, "gender-selection"], ["type", "radio", "name", "gender", "formControlName", "gender", 1, "gender-radio", 3, "value"], [3, "value"], ["formControlName", "subCategory", 1, "selectbox", "textbox-bottom", 3, "change"], [1, "file-list"], ["src", "../../../assets/file.png"], [1, "location-container", 3, "click"], [1, "location-container-complete", 3, "click"]],
        template: function RegisterPractitionerComponent_Template(rf, ctx) {
          if (rf & 1) {
            var _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](3, "form", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("ngSubmit", function RegisterPractitionerComponent_Template_form_ngSubmit_3_listener() {
              return ctx.onSubmit();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "h1", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](5, "Register as Practitioner!");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](6, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](7, "div", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](8, "label");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](9, "Photo");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](10, "app-drop-zone", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("fileEmmitor", function RegisterPractitionerComponent_Template_app_drop_zone_fileEmmitor_10_listener($event) {
              return ctx.setfile($event);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](11, "div", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](12, "label");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](13, "Title");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](14, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](15, "select", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("change", function RegisterPractitionerComponent_Template_select_change_15_listener($event) {
              return ctx.changeTitle($event);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](16, RegisterPractitionerComponent_option_16_Template, 2, 1, "option", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](17, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](18, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](19, "label");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](20, "First name");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](21, "input", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](22, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](23, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](24, "label", 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](25, "Last name");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](26, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](27, "input", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](28, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](29, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](30, "label", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](31, "Gender");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](32, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](33, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](34, RegisterPractitionerComponent_div_34_Template, 4, 2, "div", 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](35, "div", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](36, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](37, "label");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](38, "Email");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](39, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](40, "input", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](41, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](42, "div", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](43, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](44, "label", 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](45, "Phone");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](46, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](47, "select", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("change", function RegisterPractitionerComponent_Template_select_change_47_listener($event) {
              return ctx.changeCountryCode($event);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](48, RegisterPractitionerComponent_option_48_Template, 2, 2, "option", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](49, "div", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](50, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](51, "input", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](52, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](53, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](54, "label");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](55, "Specialty");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](56, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](57, "select", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("change", function RegisterPractitionerComponent_Template_select_change_57_listener($event) {
              return ctx.changeSpecialty($event);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](58, RegisterPractitionerComponent_option_58_Template, 2, 2, "option", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](59, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](60, RegisterPractitionerComponent_div_60_Template, 6, 1, "div", 24);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](61, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](62, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](63, "label");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](64, "Experience ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](65, "span", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](66, "*No more than 500 characters recommended.");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](67, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](68, "textarea", 26);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](69, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](70, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](71, "label");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](72, "About ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](73, "span", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](74, "*No more than 500 characters recommended.");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](75, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](76, "textarea", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](77, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](78, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](79, "label");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](80, "Education ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](81, "span", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](82, "*No more than 500 characters recommended.");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](83, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](84, "textarea", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](85, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](86, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](87, "label");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](88, "Price Per Session ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](89, "span", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](90, " *This will not be displayed in the app. ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](91, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](92, "input", 29);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](93, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](94, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](95, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](96, "label");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](97, "Languages");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](98, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](99, "select", 30);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("change", function RegisterPractitionerComponent_Template_select_change_99_listener($event) {
              return ctx.changeLanguage($event);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](100, RegisterPractitionerComponent_option_100_Template, 2, 2, "option", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](101, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](102, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](103, "label");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](104, "Certification and licenses ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](105, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function RegisterPractitionerComponent_Template_div_click_105_listener() {
              _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r24);

              var _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵreference"](107);

              return _r6.click();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](106, "input", 32, 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("change", function RegisterPractitionerComponent_Template_input_change_106_listener($event) {
              return ctx.selectFiles($event);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](108, RegisterPractitionerComponent_div_108_Template, 4, 1, "div", 34);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](109, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](110, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](111, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](112, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](113, "label");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](114, "Location name ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](115, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](116, "input", 35);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](117, "div");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](118, "label");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](119, "Location ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](120, RegisterPractitionerComponent_div_120_Template, 1, 0, "div", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](121, RegisterPractitionerComponent_div_121_Template, 1, 0, "div", 37);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](122, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](123, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](124, "div", 38);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](125, "input", 39);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](126, "label");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](127, "By Applying you agree to the ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](128, "a", 40);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](129, "span", 41);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](130, "terms and conditions");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](131, " and guarantee that all the information is true and valid.");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](132, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](133, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](134, "button", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function RegisterPractitionerComponent_Template_button_click_134_listener() {
              return ctx.submitHandler();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](135, " Submit ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](136, "div", 43);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("formGroup", ctx.registerPractitioner);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](13);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.titles);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](18);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.genders);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](14);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.countryCodes);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](10);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.specialties);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.showSubCategories);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](40);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.Languages);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](8);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.fileNames);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](12);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.lat == 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.lat != 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](13);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("disabled", ctx.registerPractitioner.invalid);
          }
        },
        directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["ɵangular_packages_forms_forms_ba"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormGroupDirective"], _drop_zone_drop_zone_component__WEBPACK_IMPORTED_MODULE_13__["DropZoneComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["SelectControlValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControlName"], _angular_common__WEBPACK_IMPORTED_MODULE_14__["NgForOf"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["RequiredValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NumberValueAccessor"], _angular_common__WEBPACK_IMPORTED_MODULE_14__["NgIf"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["MaxLengthValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgSelectOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["ɵangular_packages_forms_forms_z"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["RadioControlValueAccessor"]],
        styles: [".page-container[_ngcontent-%COMP%] {\n  display: flex;\n  height: 100%;\n  background: rgb(111, 98, 169);\n}\n.page-content-container[_ngcontent-%COMP%] {\n  width: 100%;\n  background-image: url('nfsWallpaper.jpg');\n  background-size: cover;\n  background-repeat: no-repeat;\n  background-position: center;\n  display: flex;\n}\n\n\n.sidebox[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 50%;\n  background: white;\n  min-width: 900px;\n  flex: 1 1 auto;\n  overflow-y: auto;\n  min-height: 0px;\n  padding: 0% 5%;\n}\n\n.top-view[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: center;\n  align-items: center;\n  height: 500px;\n  \n}\n\n.top-fields[_ngcontent-%COMP%] {\n  padding-left: 5%;\n  padding-top: 5%;\n  flex: 1;\n  justify-self: center;\n}\n\n.top-fields[_ngcontent-%COMP%]   select[_ngcontent-%COMP%] {\n  padding-left: 20px;\n  background: url('drop-down.png') no-repeat right white;\n  -webkit-appearance: none;\n  background-position-x: 95%;\n}\n\n.textbox-top[_ngcontent-%COMP%] {\n  width: 90%;\n  \n  border-radius: 25px;\n  border: 0.8px solid #ebe8f2;\n  outline: none;\n}\n\nlabel[_ngcontent-%COMP%] {\n  margin-left: 10px;\n  color: #757575;\n}\n\n.uploadfilecontainer[_ngcontent-%COMP%] {\n  flex: 1;\n  width: 400px;\n  height: 400px;\n}\n\n.upload-certificate-container[_ngcontent-%COMP%] {\n  flex: 1;\n  width: 100% !important;\n  height: 400px;\n}\n\n.bottom-fields[_ngcontent-%COMP%] {\n  margin-top: 30px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n}\n\n.bottom-fields[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\n.textbox-bottom[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 46px;\n  border-radius: 25px;\n  border: 0.8px solid #ebe8f2;\n  outline: none;\n  padding-left: 20px;\n  box-sizing: border-box !important;\n}\n\n.selectbox[_ngcontent-%COMP%] {\n  height: 46px;\n  width: 100%;\n  border-radius: 25px;\n  border: 0.8px solid #ebe8f2;\n  outline: none;\n}\n\n.gender-selection[_ngcontent-%COMP%] {\n  display: inline-flex;\n  \n}\n\n.gender-radio[_ngcontent-%COMP%] {\n  background-color: #6f62a9;\n}\n\n.bottom-fields[_ngcontent-%COMP%]   select[_ngcontent-%COMP%] {\n  padding-left: 20px;\n  background: url('drop-down.png') no-repeat right white;\n  -webkit-appearance: none;\n  background-position-x: 99%;\n}\n\n.center-align[_ngcontent-%COMP%] {\n  text-align: center;\n}\n\n.phone-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  flex-direction: row;\n}\n\n.country-code[_ngcontent-%COMP%] {\n  flex: 1;\n\n  box-sizing: border-box !important;\n}\n\n.country-code[_ngcontent-%COMP%]   select[_ngcontent-%COMP%] {\n  padding-left: 20px;\n  background: url('drop-down.png') no-repeat right white;\n  -webkit-appearance: none;\n  background-position-x: 95%;\n}\n\n.phone-number[_ngcontent-%COMP%] {\n  flex: 3;\n  box-sizing: border-box !important;\n  display: flex;\n  align-items: flex-end;\n  justify-content: flex-end;\n}\n.phone-number[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  width: 90%;\n}\n\n.phone-number[_ngcontent-%COMP%]   select[_ngcontent-%COMP%] {\n  padding-left: 20px;\n}\n\n.largetextbox[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100px;\n  border-radius: 25px;\n  border: 0.8px solid #ebe8f2;\n  outline: none;\n  font-family: \"Poppins\";\n  box-sizing: border-box !important;\n  padding: 20px;\n}\n\n.input-note[_ngcontent-%COMP%] {\n  font-size: 8pt;\n  margin-left: 10px;\n}\n\n.terms-link[_ngcontent-%COMP%] {\n  font-size: 12pt;\n  color: #6f62a9;\n}\n\n.button[_ngcontent-%COMP%] {\n  background-color: #6f62a9;\n  border: none;\n  color: white;\n  text-align: center;\n  text-decoration: none;\n  display: inline-block;\n  font-size: 16px;\n  font-weight: 500;\n  font-family: \"Poppins\";\n  cursor: pointer;\n  border-radius: 20px;\n  width: 180px;\n  height: 40px;\n  margin: 5% 30%;\n}\n\n.button[_ngcontent-%COMP%]:disabled, .button[disabled][_ngcontent-%COMP%] {\n  \n  background-color: #cccccc;\n  color: white;\n}\n\n.uploadfilecontainer2[_ngcontent-%COMP%] {\n  height: 100%;\n  border: 1px solid #ebe8f2;\n  border-radius: 10px;\n  color: rgb(97, 82, 160);\n  background-image: url('uploadicon.png');\n  background-repeat: no-repeat;\n  height: 150px;\n  background-position: center;\n}\n.location-container-complete[_ngcontent-%COMP%] {\n  height: 100%;\n  border: 1px solid #ebe8f2;\n  border-radius: 10px;\n  color: rgb(97, 82, 160);\n  background-image: url('check.png');\n  background-repeat: no-repeat;\n  height: 150px;\n  background-position: center;\n}\n.location-container[_ngcontent-%COMP%] {\n  height: 100%;\n  border: 1px solid #ebe8f2;\n  border-radius: 10px;\n  color: rgb(97, 82, 160);\n  background-image: url('drop-pin.png');\n  background-repeat: no-repeat;\n  height: 150px;\n  background-position: center;\n}\n.file-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: row;\n  border: 1px solid #ebe8f2;\n  border-radius: 10px;\n  margin-top: 10px;\n}\n.file-list[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  height: 30px;\n  align-self: center;\n  padding-left: 20px;\n  padding-right: 20px;\n  \n}\n.file-list[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  flex: 5;\n  color: #757575;\n}\n\ninput.ng-invalid.ng-touched[_ngcontent-%COMP%], select.ng-invalid.ng-touched[_ngcontent-%COMP%], textarea.ng-invalid.ng-touched[_ngcontent-%COMP%] {\n  border: 1px solid rgb(255, 0, 0);\n  background-color: rgba(255, 0, 0, 0.214);\n}\n.terms-conditions[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: row;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZ2lzdGVyLXByYWN0aXRpb25lci5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBYTtFQUNiLFlBQVk7RUFDWiw2QkFBNkI7QUFDL0I7QUFDQTtFQUNFLFdBQVc7RUFDWCx5Q0FBeUQ7RUFDekQsc0JBQXNCO0VBQ3RCLDRCQUE0QjtFQUM1QiwyQkFBMkI7RUFDM0IsYUFBYTtBQUNmO0FBRUEsS0FBSztBQUNMLHVCQUF1QjtBQUN2QjtFQUNFLFlBQVk7RUFDWixVQUFVO0VBQ1YsaUJBQWlCO0VBQ2pCLGdCQUFnQjtFQUNoQixjQUFjO0VBQ2QsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZixjQUFjO0FBQ2hCO0FBRUEsa0JBQWtCO0FBQ2xCO0VBQ0UsYUFBYTtFQUNiLGVBQWU7RUFDZix1QkFBdUI7RUFDdkIsbUJBQW1CO0VBQ25CLGFBQWE7RUFDYiw0QkFBNEI7QUFDOUI7QUFDQSx3QkFBd0I7QUFDeEI7RUFDRSxnQkFBZ0I7RUFDaEIsZUFBZTtFQUNmLE9BQU87RUFDUCxvQkFBb0I7QUFDdEI7QUFFQSwwQkFBMEI7QUFFMUI7RUFDRSxrQkFBa0I7RUFDbEIsc0RBQW9FO0VBQ3BFLHdCQUF3QjtFQUN4QiwwQkFBMEI7QUFDNUI7QUFFQSwwQkFBMEI7QUFDMUI7RUFDRSxVQUFVO0VBQ1Ysa0JBQWtCO0VBQ2xCLG1CQUFtQjtFQUNuQiwyQkFBMkI7RUFDM0IsYUFBYTtBQUNmO0FBQ0EsNkJBQTZCO0FBQzdCO0VBQ0UsaUJBQWlCO0VBQ2pCLGNBQWM7QUFDaEI7QUFFQSw0REFBNEQ7QUFDNUQ7RUFDRSxPQUFPO0VBQ1AsWUFBWTtFQUNaLGFBQWE7QUFDZjtBQUNBLHVDQUF1QztBQUN2QztFQUNFLE9BQU87RUFDUCxzQkFBc0I7RUFDdEIsYUFBYTtBQUNmO0FBRUEsc0JBQXNCO0FBQ3RCO0VBQ0UsZ0JBQWdCO0VBQ2hCLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsbUJBQW1CO0FBQ3JCO0FBQ0Esa0NBQWtDO0FBRWxDO0VBQ0UsV0FBVztBQUNiO0FBQ0EseUNBQXlDO0FBQ3pDO0VBQ0UsV0FBVztFQUNYLFlBQVk7RUFDWixtQkFBbUI7RUFDbkIsMkJBQTJCO0VBQzNCLGFBQWE7RUFDYixrQkFBa0I7RUFDbEIsaUNBQWlDO0FBQ25DO0FBRUEsZ0JBQWdCO0FBQ2hCO0VBQ0UsWUFBWTtFQUNaLFdBQVc7RUFDWCxtQkFBbUI7RUFDbkIsMkJBQTJCO0VBQzNCLGFBQWE7QUFDZjtBQUVBLDBCQUEwQjtBQUMxQjtFQUNFLG9CQUFvQjtFQUNwQix5QkFBeUI7QUFDM0I7QUFDQSxnQkFBZ0I7QUFDaEI7RUFDRSx5QkFBeUI7QUFDM0I7QUFFQSwwQkFBMEI7QUFDMUI7RUFDRSxrQkFBa0I7RUFDbEIsc0RBQW9FO0VBQ3BFLHdCQUF3QjtFQUN4QiwwQkFBMEI7QUFDNUI7QUFFQSxrQkFBa0I7QUFDbEI7RUFDRSxrQkFBa0I7QUFDcEI7QUFFQSxjQUFjO0FBQ2Q7RUFDRSxhQUFhO0VBQ2IsZUFBZTtFQUNmLG1CQUFtQjtBQUNyQjtBQUNBLHFCQUFxQjtBQUNyQjtFQUNFLE9BQU87O0VBRVAsaUNBQWlDO0FBQ25DO0FBQ0EsMEJBQTBCO0FBQzFCO0VBQ0Usa0JBQWtCO0VBQ2xCLHNEQUFvRTtFQUNwRSx3QkFBd0I7RUFDeEIsMEJBQTBCO0FBQzVCO0FBQ0EscUJBQXFCO0FBQ3JCO0VBQ0UsT0FBTztFQUNQLGlDQUFpQztFQUNqQyxhQUFhO0VBQ2IscUJBQXFCO0VBQ3JCLHlCQUF5QjtBQUMzQjtBQUNBO0VBQ0UsVUFBVTtBQUNaO0FBQ0EsMEJBQTBCO0FBQzFCO0VBQ0Usa0JBQWtCO0FBQ3BCO0FBQ0EscUJBQXFCO0FBQ3JCO0VBQ0UsV0FBVztFQUNYLGFBQWE7RUFDYixtQkFBbUI7RUFDbkIsMkJBQTJCO0VBQzNCLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsaUNBQWlDO0VBQ2pDLGFBQWE7QUFDZjtBQUVBLG1CQUFtQjtBQUNuQjtFQUNFLGNBQWM7RUFDZCxpQkFBaUI7QUFDbkI7QUFFQSw4QkFBOEI7QUFDOUI7RUFDRSxlQUFlO0VBQ2YsY0FBYztBQUNoQjtBQUVBLFdBQVc7QUFDWDtFQUNFLHlCQUF5QjtFQUN6QixZQUFZO0VBQ1osWUFBWTtFQUNaLGtCQUFrQjtFQUNsQixxQkFBcUI7RUFDckIscUJBQXFCO0VBQ3JCLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsc0JBQXNCO0VBQ3RCLGVBQWU7RUFDZixtQkFBbUI7RUFDbkIsWUFBWTtFQUNaLFlBQVk7RUFDWixjQUFjO0FBQ2hCO0FBRUEsMEJBQTBCO0FBQzFCOztFQUVFLCtCQUErQjtFQUMvQix5QkFBeUI7RUFDekIsWUFBWTtBQUNkO0FBRUEseUJBQXlCO0FBQ3pCO0VBQ0UsWUFBWTtFQUNaLHlCQUF5QjtFQUN6QixtQkFBbUI7RUFDbkIsdUJBQXVCO0VBQ3ZCLHVDQUF1RDtFQUN2RCw0QkFBNEI7RUFDNUIsYUFBYTtFQUNiLDJCQUEyQjtBQUM3QjtBQUVBO0VBQ0UsWUFBWTtFQUNaLHlCQUF5QjtFQUN6QixtQkFBbUI7RUFDbkIsdUJBQXVCO0VBQ3ZCLGtDQUFrRDtFQUNsRCw0QkFBNEI7RUFDNUIsYUFBYTtFQUNiLDJCQUEyQjtBQUM3QjtBQUVBO0VBQ0UsWUFBWTtFQUNaLHlCQUF5QjtFQUN6QixtQkFBbUI7RUFDbkIsdUJBQXVCO0VBQ3ZCLHFDQUFxRDtFQUNyRCw0QkFBNEI7RUFDNUIsYUFBYTtFQUNiLDJCQUEyQjtBQUM3QjtBQUVBO0VBQ0UsYUFBYTtFQUNiLG1CQUFtQjtFQUNuQix5QkFBeUI7RUFDekIsbUJBQW1CO0VBQ25CLGdCQUFnQjtBQUNsQjtBQUVBO0VBQ0UsWUFBWTtFQUNaLGtCQUFrQjtFQUNsQixrQkFBa0I7RUFDbEIsbUJBQW1CO0VBQ25CLGFBQWE7QUFDZjtBQUVBO0VBQ0UsT0FBTztFQUNQLGNBQWM7QUFDaEI7QUFFQSxnQkFBZ0I7QUFDaEI7OztFQUdFLGdDQUFnQztFQUNoQyx3Q0FBd0M7QUFDMUM7QUFFQTtFQUNFLGFBQWE7RUFDYixtQkFBbUI7QUFDckIiLCJmaWxlIjoicmVnaXN0ZXItcHJhY3RpdGlvbmVyLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucGFnZS1jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBoZWlnaHQ6IDEwMCU7XG4gIGJhY2tncm91bmQ6IHJnYigxMTEsIDk4LCAxNjkpO1xufVxuLnBhZ2UtY29udGVudC1jb250YWluZXIge1xuICB3aWR0aDogMTAwJTtcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi4vLi4vLi4vYXNzZXRzL25mc1dhbGxwYXBlci5qcGdcIik7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgZGlzcGxheTogZmxleDtcbn1cblxuLyogICovXG4vKiBzaWRlIGJveCBjb250YWluZXIgKi9cbi5zaWRlYm94IHtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogNTAlO1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgbWluLXdpZHRoOiA5MDBweDtcbiAgZmxleDogMSAxIGF1dG87XG4gIG92ZXJmbG93LXk6IGF1dG87XG4gIG1pbi1oZWlnaHQ6IDBweDtcbiAgcGFkZGluZzogMCUgNSU7XG59XG5cbi8qIHRvcCBjb250YWluZXIgKi9cbi50b3AtdmlldyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtd3JhcDogd3JhcDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGhlaWdodDogNTAwcHg7XG4gIC8qIGFsaWduLWNvbnRlbnQ6IHN0cmV0Y2g7ICovXG59XG4vKiB0b3AgcmlnaHQgY29udGFpbmVyICovXG4udG9wLWZpZWxkcyB7XG4gIHBhZGRpbmctbGVmdDogNSU7XG4gIHBhZGRpbmctdG9wOiA1JTtcbiAgZmxleDogMTtcbiAganVzdGlmeS1zZWxmOiBjZW50ZXI7XG59XG5cbi8qIHNlbGVjdCBmaWVsZHMgcGFkZGluZyAqL1xuXG4udG9wLWZpZWxkcyBzZWxlY3Qge1xuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG4gIGJhY2tncm91bmQ6IHVybCguLi8uLi8uLi9hc3NldHMvZHJvcC1kb3duLnBuZykgbm8tcmVwZWF0IHJpZ2h0IHdoaXRlO1xuICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XG4gIGJhY2tncm91bmQtcG9zaXRpb24teDogOTUlO1xufVxuXG4vKiB0ZXh0IGJveCBpbiB0b3AgcmlnaHQgKi9cbi50ZXh0Ym94LXRvcCB7XG4gIHdpZHRoOiA5MCU7XG4gIC8qIGhlaWdodDogNDZweDsgKi9cbiAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgYm9yZGVyOiAwLjhweCBzb2xpZCAjZWJlOGYyO1xuICBvdXRsaW5lOiBub25lO1xufVxuLyogbGFiZWwgYWJvdmUgdGhlIHRleHQgYm94ICovXG5sYWJlbCB7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBjb2xvcjogIzc1NzU3NTtcbn1cblxuLyogZmlsZSBjb250YWluZXIsIHJlc3RpcmN0aW9uIG9mIGhlaWdodCB0byBiZSBhYm92ZSA0MDBweCAqL1xuLnVwbG9hZGZpbGVjb250YWluZXIge1xuICBmbGV4OiAxO1xuICB3aWR0aDogNDAwcHg7XG4gIGhlaWdodDogNDAwcHg7XG59XG4vKiB0aGlzIG5lZWRzIHRvIGJlIGFub3RoZXIgY29udGFpbmVyICovXG4udXBsb2FkLWNlcnRpZmljYXRlLWNvbnRhaW5lciB7XG4gIGZsZXg6IDE7XG4gIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogNDAwcHg7XG59XG5cbi8qICBib3R0b20gY29udGFpbmVyICovXG4uYm90dG9tLWZpZWxkcyB7XG4gIG1hcmdpbi10b3A6IDMwcHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG4vKiAgZGl2cyBpbnNpZGUgYm90dG9tIGNvbnRhaW5lciAqL1xuXG4uYm90dG9tLWZpZWxkcyBkaXYge1xuICB3aWR0aDogMTAwJTtcbn1cbi8qIHRleHQgYm94IGluc2lkZSB0aGUgYm90dG9tIGNvbnRhaW5lciAqL1xuLnRleHRib3gtYm90dG9tIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogNDZweDtcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgYm9yZGVyOiAwLjhweCBzb2xpZCAjZWJlOGYyO1xuICBvdXRsaW5lOiBub25lO1xuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3ggIWltcG9ydGFudDtcbn1cblxuLyogc2VsZWN0IGJveCAgKi9cbi5zZWxlY3Rib3gge1xuICBoZWlnaHQ6IDQ2cHg7XG4gIHdpZHRoOiAxMDAlO1xuICBib3JkZXItcmFkaXVzOiAyNXB4O1xuICBib3JkZXI6IDAuOHB4IHNvbGlkICNlYmU4ZjI7XG4gIG91dGxpbmU6IG5vbmU7XG59XG5cbi8qIGdlbmVkZXIgc2VsZWN0aW9uIGRpdiAqL1xuLmdlbmRlci1zZWxlY3Rpb24ge1xuICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgLyogZmxleC1kaXJlY3Rpb246IHJvdzsgKi9cbn1cbi8qIHJhZGlvIGlucHV0ICovXG4uZ2VuZGVyLXJhZGlvIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzZmNjJhOTtcbn1cblxuLyogc2VsZWN0IGZpZWxkcyBwYWRkaW5nICovXG4uYm90dG9tLWZpZWxkcyBzZWxlY3Qge1xuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG4gIGJhY2tncm91bmQ6IHVybCguLi8uLi8uLi9hc3NldHMvZHJvcC1kb3duLnBuZykgbm8tcmVwZWF0IHJpZ2h0IHdoaXRlO1xuICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XG4gIGJhY2tncm91bmQtcG9zaXRpb24teDogOTklO1xufVxuXG4vKiB0aXRsZSBhbGlnaW5nICovXG4uY2VudGVyLWFsaWduIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4vKiBwaG9uZSBkaXYgKi9cbi5waG9uZS1jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LXdyYXA6IHdyYXA7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG59XG4vKiBjb3VudHJ5IGNvZGUgZGl2ICovXG4uY291bnRyeS1jb2RlIHtcbiAgZmxleDogMTtcblxuICBib3gtc2l6aW5nOiBib3JkZXItYm94ICFpbXBvcnRhbnQ7XG59XG4vKiBzZWxlY3QgZmllbGRzIHBhZGRpbmcgKi9cbi5jb3VudHJ5LWNvZGUgc2VsZWN0IHtcbiAgcGFkZGluZy1sZWZ0OiAyMHB4O1xuICBiYWNrZ3JvdW5kOiB1cmwoLi4vLi4vLi4vYXNzZXRzL2Ryb3AtZG93bi5wbmcpIG5vLXJlcGVhdCByaWdodCB3aGl0ZTtcbiAgLXdlYmtpdC1hcHBlYXJhbmNlOiBub25lO1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uLXg6IDk1JTtcbn1cbi8qIHBob25lIG51bWJlciBkaXYgKi9cbi5waG9uZS1udW1iZXIge1xuICBmbGV4OiAzO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94ICFpbXBvcnRhbnQ7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBmbGV4LWVuZDtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbn1cbi5waG9uZS1udW1iZXIgaW5wdXQge1xuICB3aWR0aDogOTAlO1xufVxuLyogc2VsZWN0IGZpZWxkcyBwYWRkaW5nICovXG4ucGhvbmUtbnVtYmVyIHNlbGVjdCB7XG4gIHBhZGRpbmctbGVmdDogMjBweDtcbn1cbi8qIHRleHRhcmVhIHN0eWxpbmcgKi9cbi5sYXJnZXRleHRib3gge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDBweDtcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgYm9yZGVyOiAwLjhweCBzb2xpZCAjZWJlOGYyO1xuICBvdXRsaW5lOiBub25lO1xuICBmb250LWZhbWlseTogXCJQb3BwaW5zXCI7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3ggIWltcG9ydGFudDtcbiAgcGFkZGluZzogMjBweDtcbn1cblxuLyogdGV4dCBhcmVhIG5vdGUgKi9cbi5pbnB1dC1ub3RlIHtcbiAgZm9udC1zaXplOiA4cHQ7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuXG4vKiB0ZXJtcyBhbmQgY29uZGl0aW9ucyBsaW5rICovXG4udGVybXMtbGluayB7XG4gIGZvbnQtc2l6ZTogMTJwdDtcbiAgY29sb3I6ICM2ZjYyYTk7XG59XG5cbi8qIEJ1dHRvbiAqL1xuLmJ1dHRvbiB7XG4gIGJhY2tncm91bmQtY29sb3I6ICM2ZjYyYTk7XG4gIGJvcmRlcjogbm9uZTtcbiAgY29sb3I6IHdoaXRlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtZmFtaWx5OiBcIlBvcHBpbnNcIjtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICB3aWR0aDogMTgwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgbWFyZ2luOiA1JSAzMCU7XG59XG5cbi8qIGlmIGJ1dHRvbiBpcyBkaXNhYmxlZCAqL1xuLmJ1dHRvbjpkaXNhYmxlZCxcbi5idXR0b25bZGlzYWJsZWRdIHtcbiAgLyogYm9yZGVyOiAxcHggc29saWQgIzk5OTk5OTsgKi9cbiAgYmFja2dyb3VuZC1jb2xvcjogI2NjY2NjYztcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4vKiBVcGxvYWQgbXVsdGlwbGUgZmlsZSAqL1xuLnVwbG9hZGZpbGVjb250YWluZXIyIHtcbiAgaGVpZ2h0OiAxMDAlO1xuICBib3JkZXI6IDFweCBzb2xpZCAjZWJlOGYyO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBjb2xvcjogcmdiKDk3LCA4MiwgMTYwKTtcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi4vLi4vLi4vYXNzZXRzL3VwbG9hZGljb24ucG5nXCIpO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBoZWlnaHQ6IDE1MHB4O1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XG59XG5cbi5sb2NhdGlvbi1jb250YWluZXItY29tcGxldGUge1xuICBoZWlnaHQ6IDEwMCU7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNlYmU4ZjI7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIGNvbG9yOiByZ2IoOTcsIDgyLCAxNjApO1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLi8uLi8uLi9hc3NldHMvY2hlY2sucG5nXCIpO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBoZWlnaHQ6IDE1MHB4O1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XG59XG5cbi5sb2NhdGlvbi1jb250YWluZXIge1xuICBoZWlnaHQ6IDEwMCU7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNlYmU4ZjI7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIGNvbG9yOiByZ2IoOTcsIDgyLCAxNjApO1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLi8uLi8uLi9hc3NldHMvZHJvcC1waW4ucG5nXCIpO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBoZWlnaHQ6IDE1MHB4O1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XG59XG5cbi5maWxlLWxpc3Qge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICBib3JkZXI6IDFweCBzb2xpZCAjZWJlOGYyO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuXG4uZmlsZS1saXN0IGltZyB7XG4gIGhlaWdodDogMzBweDtcbiAgYWxpZ24tc2VsZjogY2VudGVyO1xuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDIwcHg7XG4gIC8qIGZsZXg6IDI7ICovXG59XG5cbi5maWxlLWxpc3QgcCB7XG4gIGZsZXg6IDU7XG4gIGNvbG9yOiAjNzU3NTc1O1xufVxuXG4vKiB2YWxpZGF0aW9uICAqL1xuaW5wdXQubmctaW52YWxpZC5uZy10b3VjaGVkLFxuc2VsZWN0Lm5nLWludmFsaWQubmctdG91Y2hlZCxcbnRleHRhcmVhLm5nLWludmFsaWQubmctdG91Y2hlZCB7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYigyNTUsIDAsIDApO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI1NSwgMCwgMCwgMC4yMTQpO1xufVxuXG4udGVybXMtY29uZGl0aW9ucyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG59XG4iXX0= */"]
      });
      /***/
    },

    /***/
    "9Gt3":
    /*!**************************************************!*\
      !*** ./src/app/drop-zone/drop-zone.component.ts ***!
      \**************************************************/

    /*! exports provided: DropZoneComponent */

    /***/
    function Gt3(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "DropZoneComponent", function () {
        return DropZoneComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _services_dropzone_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ../services/dropzone.service */
      "2aaj");
      /* harmony import */


      var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/material/snack-bar */
      "dNgK");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");

      var _c0 = function _c0(a0, a1) {
        return {
          "background-image": a0,
          "background-size": a1
        };
      };

      var DropZoneComponent = /*#__PURE__*/function () {
        function DropZoneComponent(DS, _snackBar) {
          _classCallCheck(this, DropZoneComponent);

          this.DS = DS;
          this._snackBar = _snackBar;
          this.fileEmmitor = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
          this.size = '170px';
          this.Image = '../../assets/uploadicon.png';
          this.files = [];
          this.ab = '';
        }

        _createClass(DropZoneComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this3 = this;

            setTimeout(function () {
              _this3.setBackground();
            }, 3000);
          }
        }, {
          key: "setBackground",
          value: function setBackground() {
            this.Image = this.DS.image;
            this.size = this.DS.size;
          }
        }, {
          key: "uploadFile",
          value: function uploadFile(event) {
            var _this4 = this;

            this.element = event[0];

            if (this.element.size < 2000000) {
              console.log(this.element.size + ' image size');
              this.ab = this.element.name;
              this.files = this.element;
              this.fileEmmitor.emit(this.element); // this.Image = element.name;

              var reader = new FileReader();
              reader.readAsDataURL(event[0]);

              reader.onload = function (_event) {
                _this4.urlRead = reader.result;
                _this4.Image = _this4.urlRead;
                _this4.size = 'cover';
              };

              console.log(this.Image);
            } else {
              var snackbarRef = this._snackBar.open('Image size is too large', 'Dismiss', {
                duration: 5000,
                panelClass: ['snackbarError']
              });

              snackbarRef.onAction().subscribe(function () {});
            }
          }
        }]);

        return DropZoneComponent;
      }();

      DropZoneComponent.ɵfac = function DropZoneComponent_Factory(t) {
        return new (t || DropZoneComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_services_dropzone_service__WEBPACK_IMPORTED_MODULE_1__["DropzoneService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_2__["MatSnackBar"]));
      };

      DropZoneComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: DropZoneComponent,
        selectors: [["app-drop-zone"]],
        outputs: {
          fileEmmitor: "fileEmmitor"
        },
        decls: 8,
        vars: 5,
        consts: [["appDropZone", "", 1, "uploadfilecontainer", 3, "ngStyle", "click", "onFileDropped"], ["hidden", "", "type", "file", "required", "", 3, "change"], ["fileInput", ""], [1, "textdrop"]],
        template: function DropZoneComponent_Template(rf, ctx) {
          if (rf & 1) {
            var _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DropZoneComponent_Template_div_click_0_listener() {
              _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);

              var _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](2);

              return _r0.click();
            })("onFileDropped", function DropZoneComponent_Template_div_onFileDropped_0_listener($event) {
              return ctx.uploadFile($event);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "input", 1, 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("change", function DropZoneComponent_Template_input_change_1_listener($event) {
              return ctx.uploadFile($event.target.files);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "Drag and Drop Image or Click to Browse");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](2, _c0, "url(" + ctx.Image + ")", ctx.size));

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("file name: ", ctx.ab, "");
          }
        },
        directives: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["NgStyle"]],
        styles: [".uploadfilecontainer[_ngcontent-%COMP%] {\n  background-image: url('uploadicon.png');\n  background-repeat: no-repeat;\n  background-size: 170px;\n  background-position: center;\n  height: 100%;\n  width: 100%;\n  margin: 20px auto;\n  border: 0.8px solid #ebe8f2;\n  border-radius: 10px;\n  color: rgb(97, 82, 160);\n}\n\n.uploadfilecontainer[_ngcontent-%COMP%]:hover {\n  cursor: pointer;\n  background-color: rgba(111, 98, 169, 0.529) !important;\n  opacity: 0.8;\n}\n\n.textdrop[_ngcontent-%COMP%] {\n  transform: translate(0%, 420%);\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRyb3Atem9uZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsdUNBQW9EO0VBQ3BELDRCQUE0QjtFQUM1QixzQkFBc0I7RUFDdEIsMkJBQTJCO0VBQzNCLFlBQVk7RUFDWixXQUFXO0VBQ1gsaUJBQWlCO0VBQ2pCLDJCQUEyQjtFQUMzQixtQkFBbUI7RUFDbkIsdUJBQXVCO0FBQ3pCOztBQUVBO0VBQ0UsZUFBZTtFQUNmLHNEQUFzRDtFQUN0RCxZQUFZO0FBQ2Q7O0FBRUE7RUFDRSw4QkFBOEI7RUFDOUIsa0JBQWtCO0FBQ3BCIiwiZmlsZSI6ImRyb3Atem9uZS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnVwbG9hZGZpbGVjb250YWluZXIge1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLi8uLi9hc3NldHMvdXBsb2FkaWNvbi5wbmdcIik7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIGJhY2tncm91bmQtc2l6ZTogMTcwcHg7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcbiAgbWFyZ2luOiAyMHB4IGF1dG87XG4gIGJvcmRlcjogMC44cHggc29saWQgI2ViZThmMjtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgY29sb3I6IHJnYig5NywgODIsIDE2MCk7XG59XG5cbi51cGxvYWRmaWxlY29udGFpbmVyOmhvdmVyIHtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDExMSwgOTgsIDE2OSwgMC41MjkpICFpbXBvcnRhbnQ7XG4gIG9wYWNpdHk6IDAuODtcbn1cblxuLnRleHRkcm9wIHtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMCUsIDQyMCUpO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4iXX0= */"]
      });
      /***/
    },

    /***/
    "AytR":
    /*!*****************************************!*\
      !*** ./src/environments/environment.ts ***!
      \*****************************************/

    /*! exports provided: environment */

    /***/
    function AytR(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "environment", function () {
        return environment;
      }); // This file can be replaced during build by using the `fileReplacements` array.
      // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
      // The list of file replacements can be found in `angular.json`.


      var environment = {
        production: false,
        SENDGRID_API_KEY: "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"
      };
      /*
       * For easier debugging in development mode, you can import the following file
       * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
       *
       * This import should be commented out in production mode because it will have a negative impact
       * on performance if an error is thrown.
       */
      // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

      /***/
    },

    /***/
    "SZuB":
    /*!******************************************!*\
      !*** ./src/app/constants/specialties.ts ***!
      \******************************************/

    /*! exports provided: SPECIALTIES, SUB_CATEGORIES_ALTERNATIVE, SUB_CATEGORIES_BEHAVRIORAL */

    /***/
    function SZuB(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SPECIALTIES", function () {
        return SPECIALTIES;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SUB_CATEGORIES_ALTERNATIVE", function () {
        return SUB_CATEGORIES_ALTERNATIVE;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SUB_CATEGORIES_BEHAVRIORAL", function () {
        return SUB_CATEGORIES_BEHAVRIORAL;
      });

      var SPECIALTIES = ["Psychology", "Psychiatry", "Behavioral Therapy", "Alternative Healing", "Counselor", // this will be considered as a Counselor
      "Legal Representative"];
      var SUB_CATEGORIES_ALTERNATIVE = ["Music Therapy", "Play Therapy", "Art Therapy", "Sex Therapy", "Hypnotic Therapy", "Speech and language Therapy", "Occupational Therapy", "Life coach", "Other"];
      var SUB_CATEGORIES_BEHAVRIORAL = ["ABA Therapy"];
      /***/
    },

    /***/
    "Sy1n":
    /*!**********************************!*\
      !*** ./src/app/app.component.ts ***!
      \**********************************/

    /*! exports provided: AppComponent */

    /***/
    function Sy1n(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
        return AppComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/material/snack-bar */
      "dNgK");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");

      var AppComponent = /*#__PURE__*/function () {
        function AppComponent(snackBar) {
          _classCallCheck(this, AppComponent);

          this.snackBar = snackBar;
          this.title = "NFSPractioner3";
        }

        _createClass(AppComponent, [{
          key: "openSuccessSnackBar",
          value: function openSuccessSnackBar(message) {
            this.snackBar.open(message, "Dismiss", {
              duration: 3000,
              panelClass: ["snackbar"]
            });
          } // failure snack bar

        }, {
          key: "openFailureSnackBar",
          value: function openFailureSnackBar(message) {
            this.snackBar.open(message, "Dismiss", {
              duration: 3000,
              panelClass: ["snackbar"]
            });
          }
        }]);

        return AppComponent;
      }();

      AppComponent.ɵfac = function AppComponent_Factory(t) {
        return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_1__["MatSnackBar"]));
      };

      AppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: AppComponent,
        selectors: [["app-root"]],
        decls: 1,
        vars: 0,
        template: function AppComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
          }
        },
        directives: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterOutlet"]],
        styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAuY29tcG9uZW50LmNzcyJ9 */"]
      });
      /***/
    },

    /***/
    "ZAI4":
    /*!*******************************!*\
      !*** ./src/app/app.module.ts ***!
      \*******************************/

    /*! exports provided: AppModule */

    /***/
    function ZAI4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppModule", function () {
        return AppModule;
      });
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/platform-browser */
      "jhN1");
      /* harmony import */


      var _angular_fire__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/fire */
      "spgP");
      /* harmony import */


      var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/fire/firestore */
      "I/3d");
      /* harmony import */


      var _angular_fire_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/fire/storage */
      "Vaw3");
      /* harmony import */


      var _app_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./app-routing.module */
      "vY5A");
      /* harmony import */


      var _app_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./app.component */
      "Sy1n");
      /* harmony import */


      var _drop_zone_drop_zone_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./drop-zone/drop-zone.component */
      "9Gt3");
      /* harmony import */


      var _screens_register_practitioner_register_practitioner_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./screens/register-practitioner/register-practitioner.component */
      "95/t");
      /* harmony import */


      var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @angular/material/snack-bar */
      "dNgK");
      /* harmony import */


      var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/material/dialog */
      "0IaG");
      /* harmony import */


      var _agm_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @agm/core */
      "pxUr");
      /* harmony import */


      var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @angular/platform-browser/animations */
      "R1ws");
      /* harmony import */


      var _components_location_picker_location_picker_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! ./components/location-picker/location-picker.component */
      "bY5k");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var firebaseConfig = {
        apiKey: "AIzaSyDpZ8iww9uPG0gnqA0yHO9gZlBP6nttXuc",
        authDomain: "nfsapp-390d4.firebaseapp.com",
        databaseURL: "https://nfsapp-390d4.firebaseio.com",
        projectId: "nfsapp-390d4",
        storageBucket: "nfsapp-390d4.appspot.com",
        messagingSenderId: "1013389679732",
        appId: "1:1013389679732:web:594ecaed7f210b13e5c521",
        measurementId: "G-7HFYE6799H"
      }; // var firebaseConfig = {
      //   apiKey: "AIzaSyCSAlM97c2AG4OXMtBmUNuSjecONPoUUlY",
      //   authDomain: "angularfire-20b5b.firebaseapp.com",
      //   databaseURL: "https://angularfire-20b5b.firebaseio.com",
      //   projectId: "angularfire-20b5b",
      //   storageBucket: "angularfire-20b5b.appspot.com",
      //   messagingSenderId: "652878430680",
      //   appId: "1:652878430680:web:538e31872a6f7d909032ad",
      // };

      var AppModule = function AppModule() {
        _classCallCheck(this, AppModule);
      };

      AppModule.ɵfac = function AppModule_Factory(t) {
        return new (t || AppModule)();
      };

      AppModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineNgModule"]({
        type: AppModule,
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"]]
      });
      AppModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineInjector"]({
        providers: [],
        imports: [[_agm_core__WEBPACK_IMPORTED_MODULE_11__["AgmCoreModule"].forRoot({
          apiKey: "AIzaSyDpZ8iww9uPG0gnqA0yHO9gZlBP6nttXuc",
          // AIzaSyCcLZGjrULCMhRZLkRHAD-mO92j06Vidyk
          libraries: ["places"]
        }), _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_5__["AppRoutingModule"], _angular_fire__WEBPACK_IMPORTED_MODULE_2__["AngularFireModule"].initializeApp(firebaseConfig), _angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["ReactiveFormsModule"], _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_3__["AngularFirestoreModule"], _angular_fire_storage__WEBPACK_IMPORTED_MODULE_4__["AngularFireStorageModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_12__["BrowserAnimationsModule"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_9__["MatSnackBarModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_10__["MatDialogModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HttpClientModule"]]]
      });

      (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵsetNgModuleScope"](AppModule, {
          declarations: [_app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"], _screens_register_practitioner_register_practitioner_component__WEBPACK_IMPORTED_MODULE_8__["RegisterPractitionerComponent"], _drop_zone_drop_zone_component__WEBPACK_IMPORTED_MODULE_7__["DropZoneComponent"], _components_location_picker_location_picker_component__WEBPACK_IMPORTED_MODULE_13__["LocationPickerComponent"]],
          imports: [_agm_core__WEBPACK_IMPORTED_MODULE_11__["AgmCoreModule"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_5__["AppRoutingModule"], _angular_fire__WEBPACK_IMPORTED_MODULE_2__["AngularFireModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__["ReactiveFormsModule"], _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_3__["AngularFirestoreModule"], _angular_fire_storage__WEBPACK_IMPORTED_MODULE_4__["AngularFireStorageModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_12__["BrowserAnimationsModule"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_9__["MatSnackBarModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_10__["MatDialogModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HttpClientModule"]]
        });
      })();
      /***/

    },

    /***/
    "bY5k":
    /*!*************************************************************************!*\
      !*** ./src/app/components/location-picker/location-picker.component.ts ***!
      \*************************************************************************/

    /*! exports provided: LocationPickerComponent */

    /***/
    function bY5k(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "LocationPickerComponent", function () {
        return LocationPickerComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _agm_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @agm/core */
      "pxUr");
      /* harmony import */


      var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/material/dialog */
      "0IaG");
      /* harmony import */


      var src_app_services_practitioner_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! src/app/services/practitioner.service */
      "mqhL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");

      var _c0 = ["search"];

      function LocationPickerComponent_label_2_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "label");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Enter address");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function LocationPickerComponent_input_3_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 8, 9);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keydown.enter", function LocationPickerComponent_input_3_Template_input_keydown_enter_0_listener($event) {
            return $event.preventDefault();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      var LocationPickerComponent = /*#__PURE__*/function () {
        function LocationPickerComponent(mapsAPILoader, ngZone, dialog, practitionerService) {
          _classCallCheck(this, LocationPickerComponent);

          this.mapsAPILoader = mapsAPILoader;
          this.ngZone = ngZone;
          this.dialog = dialog;
          this.practitionerService = practitionerService; // location picker

          this.lat = 26.233974552113157;
          this.lng = 50.57565070202837;
          this.zoom = 16;
          this.searchable = true;
        }

        _createClass(LocationPickerComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this5 = this;

            // agm component
            this.mapsAPILoader.load().then(function () {
              _this5.setCurrentLocation();

              _this5.geoCoder = new google.maps.Geocoder();

              if (_this5.searchable) {
                var autocomplete = new google.maps.places.Autocomplete(_this5.searchElementRef.nativeElement);
                autocomplete.addListener("place_changed", function () {
                  _this5.ngZone.run(function () {
                    //get the place result
                    var place = autocomplete.getPlace(); //verify result

                    if (place.geometry === undefined || place.geometry === null) {
                      return;
                    } //set latitude, longitude and zoom


                    _this5.lat = place.geometry.location.lat();
                    _this5.lng = place.geometry.location.lng();
                    _this5.zoom = 16;
                  });
                });
              }
            });
          } // Get Current Location Coordinates

        }, {
          key: "setCurrentLocation",
          value: function setCurrentLocation() {
            var _this6 = this;

            if ("geolocation" in navigator) {
              navigator.geolocation.getCurrentPosition(function (position) {
                _this6.lat = position.coords.latitude;
                _this6.lng = position.coords.longitude;
                _this6.zoom = 16;

                _this6.getAddress(_this6.lat, _this6.lng);
              });
            }
          }
        }, {
          key: "markerDragEnd",
          value: function markerDragEnd($event) {
            console.log($event);
            this.lat = $event.coords.lat;
            this.lng = $event.coords.lng;
            this.getAddress(this.lat, this.lng);
          }
        }, {
          key: "getAddress",
          value: function getAddress(latitude, longitude) {
            var _this7 = this;

            this.geoCoder.geocode({
              location: {
                lat: latitude,
                lng: longitude
              }
            }, function (results, status) {
              console.log(results);
              console.log(status);

              if (status === "OK") {
                if (results[0]) {
                  _this7.zoom = 16;
                  _this7.address = results[0].formatted_address;
                } else {
                  window.alert("No results found");
                }
              } else {
                window.alert("Geocoder failed due to: " + status);
              }
            });
          }
        }, {
          key: "cancelDialog",
          value: function cancelDialog() {
            this.dialog.closeAll();
          }
        }, {
          key: "ConfirmSelection",
          value: function ConfirmSelection() {
            this.practitionerService.lat = this.lat;
            this.practitionerService.longt = this.lng;
            console.log("the coordinates are", " the latitude" + this.practitionerService.lat + " the longtitude" + this.practitionerService.longt);
            this.dialog.closeAll();
          }
        }]);

        return LocationPickerComponent;
      }();

      LocationPickerComponent.ɵfac = function LocationPickerComponent_Factory(t) {
        return new (t || LocationPickerComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_agm_core__WEBPACK_IMPORTED_MODULE_1__["MapsAPILoader"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__["MatDialog"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_services_practitioner_service__WEBPACK_IMPORTED_MODULE_3__["PractitionerService"]));
      };

      LocationPickerComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: LocationPickerComponent,
        selectors: [["app-location-picker"]],
        viewQuery: function LocationPickerComponent_Query(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, 1);
          }

          if (rf & 2) {
            var _t;

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.searchElementRef = _t.first);
          }
        },
        decls: 11,
        vars: 9,
        consts: [[1, "map"], [1, "form-group"], [4, "ngIf"], ["type", "text", "class", "form-control input-container", "placeholder", "Search Nearest Location", "autocorrect", "off", "autocapitalize", "off", "spellcheck", "off", "type", "text", 3, "keydown.enter", 4, "ngIf"], [3, "latitude", "longitude", "mapTypeControl", "zoom"], [3, "latitude", "longitude", "markerDraggable", "dragEnd"], [1, "map-controles"], [3, "click"], ["type", "text", "placeholder", "Search Nearest Location", "autocorrect", "off", "autocapitalize", "off", "spellcheck", "off", "type", "text", 1, "form-control", "input-container", 3, "keydown.enter"], ["search", ""]],
        template: function LocationPickerComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, LocationPickerComponent_label_2_Template, 2, 0, "label", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, LocationPickerComponent_input_3_Template, 2, 0, "input", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "agm-map", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "agm-marker", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("dragEnd", function LocationPickerComponent_Template_agm_marker_dragEnd_5_listener($event) {
              return ctx.markerDragEnd($event);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "button", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function LocationPickerComponent_Template_button_click_7_listener() {
              return ctx.cancelDialog();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "Close");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function LocationPickerComponent_Template_button_click_9_listener() {
              return ctx.ConfirmSelection();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Confirm");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.searchable);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.searchable);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("latitude", ctx.lat)("longitude", ctx.lng)("mapTypeControl", true)("zoom", ctx.zoom);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("latitude", ctx.lat)("longitude", ctx.lng)("markerDraggable", true);
          }
        },
        directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["NgIf"], _agm_core__WEBPACK_IMPORTED_MODULE_1__["AgmMap"], _agm_core__WEBPACK_IMPORTED_MODULE_1__["AgmMarker"]],
        styles: ["agm-map[_ngcontent-%COMP%] {\n  height: 300px;\n}\n\n.map[_ngcontent-%COMP%] {\n  padding: 1rem;\n  display: flex;\n  flex-direction: column;\n}\n\n .mat-dialog-container {\n  display: block;\n  border-radius: 4px;\n  box-sizing: border-box;\n  border-radius: 20px;\n  overflow: auto;\n  outline: 0;\n  width: 100%;\n  height: 100%;\n  min-height: inherit;\n  max-height: inherit;\n  padding: 0;\n}\n\n .mat-dialog-container .map-controles {\n  width: 100%;\n  display: flex;\n  display: flex;\n  justify-content: space-around;\n}\n\n .mat-dialog-container button {\n  background-color: #6f62a9;\n  border: none;\n  color: white;\n  text-align: center;\n  text-decoration: none;\n  font-size: 1rem;\n  font-weight: 500;\n  font-family: \"Poppins\";\n  cursor: pointer;\n  border-radius: 20px;\n  width: 180px;\n  height: 40px;\n  margin-top: 5px;\n  margin-bottom: 5px;\n  \n}\n\n.form-group[_ngcontent-%COMP%] {\n  margin-top: 1rem;\n  \n}\n\n.form-group[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  font-size: 0.9rem;\n  margin-left: 1rem;\n  font-family: \"Poppins\";\n}\n\n.form-group[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  \n  font-family: \"Poppins\";\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvY2F0aW9uLXBpY2tlci5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBYTtBQUNmOztBQUVBO0VBQ0UsYUFBYTtFQUNiLGFBQWE7RUFDYixzQkFBc0I7QUFDeEI7O0FBRUE7RUFDRSxjQUFjO0VBQ2Qsa0JBQWtCO0VBQ2xCLHNCQUFzQjtFQUN0QixtQkFBbUI7RUFDbkIsY0FBYztFQUNkLFVBQVU7RUFDVixXQUFXO0VBQ1gsWUFBWTtFQUNaLG1CQUFtQjtFQUNuQixtQkFBbUI7RUFDbkIsVUFBVTtBQUNaOztBQUVBO0VBQ0UsV0FBVztFQUNYLGFBQWE7RUFDYixhQUFhO0VBQ2IsNkJBQTZCO0FBQy9COztBQUVBO0VBQ0UseUJBQXlCO0VBQ3pCLFlBQVk7RUFDWixZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCLHFCQUFxQjtFQUNyQixlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLHNCQUFzQjtFQUN0QixlQUFlO0VBQ2YsbUJBQW1CO0VBQ25CLFlBQVk7RUFDWixZQUFZO0VBQ1osZUFBZTtFQUNmLGtCQUFrQjtFQUNsQixvQkFBb0I7QUFDdEI7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEI7d0JBQ3NCO0FBQ3hCOztBQUVBO0VBQ0UsaUJBQWlCO0VBQ2pCLGlCQUFpQjtFQUNqQixzQkFBc0I7QUFDeEI7O0FBRUE7RUFDRTtzQkFDb0I7RUFDcEIsc0JBQXNCO0FBQ3hCIiwiZmlsZSI6ImxvY2F0aW9uLXBpY2tlci5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiYWdtLW1hcCB7XG4gIGhlaWdodDogMzAwcHg7XG59XG5cbi5tYXAge1xuICBwYWRkaW5nOiAxcmVtO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xufVxuXG46Om5nLWRlZXAubWF0LWRpYWxvZy1jb250YWluZXIge1xuICBkaXNwbGF5OiBibG9jaztcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICBvdmVyZmxvdzogYXV0bztcbiAgb3V0bGluZTogMDtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgbWluLWhlaWdodDogaW5oZXJpdDtcbiAgbWF4LWhlaWdodDogaW5oZXJpdDtcbiAgcGFkZGluZzogMDtcbn1cblxuOjpuZy1kZWVwLm1hdC1kaWFsb2ctY29udGFpbmVyIC5tYXAtY29udHJvbGVzIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xufVxuXG46Om5nLWRlZXAubWF0LWRpYWxvZy1jb250YWluZXIgYnV0dG9uIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzZmNjJhOTtcbiAgYm9yZGVyOiBub25lO1xuICBjb2xvcjogd2hpdGU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xuICBmb250LXNpemU6IDFyZW07XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtZmFtaWx5OiBcIlBvcHBpbnNcIjtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICB3aWR0aDogMTgwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgbWFyZ2luLXRvcDogNXB4O1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gIC8qIG1hcmdpbjogNSUgMzAlOyAqL1xufVxuXG4uZm9ybS1ncm91cCB7XG4gIG1hcmdpbi10b3A6IDFyZW07XG4gIC8qIHBhZGRpbmctbGVmdDogMXJlbTtcbiAgcGFkZGluZy1yaWdodDogMXJlbTsgKi9cbn1cblxuLmZvcm0tZ3JvdXAgbGFiZWwge1xuICBmb250LXNpemU6IDAuOXJlbTtcbiAgbWFyZ2luLWxlZnQ6IDFyZW07XG4gIGZvbnQtZmFtaWx5OiBcIlBvcHBpbnNcIjtcbn1cblxuLmZvcm0tZ3JvdXAgaW5wdXQge1xuICAvKiBmb250LXNpemU6IDAuOXJlbTtcbiAgbWFyZ2luLWxlZnQ6IDFyZW07ICovXG4gIGZvbnQtZmFtaWx5OiBcIlBvcHBpbnNcIjtcbn1cbiJdfQ== */"]
      });
      /***/
    },

    /***/
    "bl9C":
    /*!****************************************!*\
      !*** ./src/app/constants/constants.ts ***!
      \****************************************/

    /*! exports provided: TITLES, COUNTRY_CODES, GENDERS, LANGUAGES, SENDGRID_API_KEY */

    /***/
    function bl9C(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TITLES", function () {
        return TITLES;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "COUNTRY_CODES", function () {
        return COUNTRY_CODES;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "GENDERS", function () {
        return GENDERS;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "LANGUAGES", function () {
        return LANGUAGES;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SENDGRID_API_KEY", function () {
        return SENDGRID_API_KEY;
      });

      var TITLES = ["Dr.", "Ms.", "Mrs.", "Mr."]; // TODO: adding countries GCC/ EUROPE/ USA

      var COUNTRY_CODES = [{
        code: "+973",
        name: "Bahrain"
      }, {
        code: "+213",
        name: "Algeria"
      }, {
        code: "+61",
        name: "Australia"
      }, {
        code: "+32",
        name: "Belgium"
      }, {
        code: "+1",
        name: "Canada"
      }, {
        code: "+385",
        name: "Croatia"
      }, {
        code: "+420",
        name: "Czech Republic"
      }, {
        code: "+45",
        name: "Denmark"
      }, {
        code: "+358",
        name: "Finland"
      }, {
        code: "+33",
        name: "France"
      }, {
        code: "+49",
        name: "Germany"
      }, {
        code: "+30",
        name: "Greece"
      }, {
        code: "+299",
        name: "Greenland"
      }, {
        code: "+36",
        name: "Hungary"
      }, {
        code: "+354",
        name: "Iceland"
      }, {
        code: "+98",
        name: "Iran"
      }, {
        code: "+964",
        name: "Iraq"
      }, {
        code: "+353",
        name: "Ireland"
      }, {
        code: "+972",
        name: "Israel"
      }, {
        code: "+39",
        name: "Italy"
      }, {
        code: "+81",
        name: "Japan"
      }, {
        code: "+962",
        name: "Jordan"
      }, {
        code: "+965",
        name: "Kuwait"
      }, {
        code: "+961",
        name: "Lebanon"
      }, {
        code: "+352",
        name: "Luxembourg"
      }, {
        code: "+356",
        name: "Malta"
      }, {
        code: "+377",
        name: "Monaco"
      }, {
        code: "+31",
        name: "Netherlands"
      }, {
        code: "+599",
        name: "Netherlands Antilles"
      }, {
        code: "+64",
        name: "New Zealand"
      }, {
        code: "+970",
        name: "Palestinian Territory"
      }, {
        code: "+351",
        name: "Portugal"
      }, {
        code: "+974",
        name: "Qatar"
      }, {
        code: "+966",
        name: "Saudi Arabia"
      }, {
        code: "+65",
        name: "Singapore"
      }, {
        code: "+82",
        name: "South Korea"
      }, {
        code: "+34",
        name: "Spain"
      }, {
        code: "+46",
        name: "Sweden"
      }, {
        code: "+41",
        name: "Switzerland"
      }, {
        code: "+963",
        name: "Syria"
      }, {
        code: "+216",
        name: "Tunisia"
      }, {
        code: "+90",
        name: "Turkey"
      }, {
        code: "+971",
        name: "United Arab Emirates"
      }, {
        code: "+44",
        name: "United Kingdom"
      }, {
        code: "+1",
        name: "United States"
      }, {
        code: "+967",
        name: "Yemen"
      }];
      var GENDERS = ["Male", "Female"];
      var LANGUAGES = ["Arabic", "English"];
      var SENDGRID_API_KEY = "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"; // {
      //   "countries": [
      //     {
      //       code: "+7 840",
      //       "name": "Abkhazia"
      //     },
      //     {
      //       "code": "+93",
      //       "name": "Afghanistan"
      //     },
      //     {
      //       "code": "+355",
      //       "name": "Albania"
      //     },
      //     {
      //       "code": "+213",
      //       "name": "Algeria"
      //     },
      //     {
      //       "code": "+1 684",
      //       "name": "American Samoa"
      //     },
      //     {
      //       "code": "+376",
      //       "name": "Andorra"
      //     },
      //     {
      //       "code": "+244",
      //       "name": "Angola"
      //     },
      //     {
      //       "code": "+1 264",
      //       "name": "Anguilla"
      //     },
      //     {
      //       "code": "+1 268",
      //       "name": "Antigua and Barbuda"
      //     },
      //     {
      //       "code": "+54",
      //       "name": "Argentina"
      //     },
      //     {
      //       "code": "+374",
      //       "name": "Armenia"
      //     },
      //     {
      //       "code": "+297",
      //       "name": "Aruba"
      //     },
      //     {
      //       "code": "+247",
      //       "name": "Ascension"
      //     },
      //     {
      //       "code": "+61",
      //       "name": "Australia"
      //     },
      //     {
      //       "code": "+672",
      //       "name": "Australian External Territories"
      //     },
      //     {
      //       "code": "+43",
      //       "name": "Austria"
      //     },
      //     {
      //       "code": "+994",
      //       "name": "Azerbaijan"
      //     },
      //     {
      //       "code": "+1 242",
      //       "name": "Bahamas"
      //     },
      //     {
      //       "code": "+973",
      //       "name": "Bahrain"
      //     },
      //     {
      //       "code": "+880",
      //       "name": "Bangladesh"
      //     },
      //     {
      //       "code": "+1 246",
      //       "name": "Barbados"
      //     },
      //     {
      //       "code": "+1 268",
      //       "name": "Barbuda"
      //     },
      //     {
      //       "code": "+375",
      //       "name": "Belarus"
      //     },
      //     {
      //       "code": "+32",
      //       "name": "Belgium"
      //     },
      //     {
      //       "code": "+501",
      //       "name": "Belize"
      //     },
      //     {
      //       "code": "+229",
      //       "name": "Benin"
      //     },
      //     {
      //       "code": "+1 441",
      //       "name": "Bermuda"
      //     },
      //     {
      //       "code": "+975",
      //       "name": "Bhutan"
      //     },
      //     {
      //       "code": "+591",
      //       "name": "Bolivia"
      //     },
      //     {
      //       "code": "+387",
      //       "name": "Bosnia and Herzegovina"
      //     },
      //     {
      //       "code": "+267",
      //       "name": "Botswana"
      //     },
      //     {
      //       "code": "+55",
      //       "name": "Brazil"
      //     },
      //     {
      //       "code": "+246",
      //       "name": "British Indian Ocean Territory"
      //     },
      //     {
      //       "code": "+1 284",
      //       "name": "British Virgin Islands"
      //     },
      //     {
      //       "code": "+673",
      //       "name": "Brunei"
      //     },
      //     {
      //       "code": "+359",
      //       "name": "Bulgaria"
      //     },
      //     {
      //       "code": "+226",
      //       "name": "Burkina Faso"
      //     },
      //     {
      //       "code": "+257",
      //       "name": "Burundi"
      //     },
      //     {
      //       "code": "+855",
      //       "name": "Cambodia"
      //     },
      //     {
      //       "code": "+237",
      //       "name": "Cameroon"
      //     },
      //     {
      //       "code": "+1",
      //       "name": "Canada"
      //     },
      //     {
      //       "code": "+238",
      //       "name": "Cape Verde"
      //     },
      //     {
      //       "code": "+ 345",
      //       "name": "Cayman Islands"
      //     },
      //     {
      //       "code": "+236",
      //       "name": "Central African Republic"
      //     },
      //     {
      //       "code": "+235",
      //       "name": "Chad"
      //     },
      //     {
      //       "code": "+56",
      //       "name": "Chile"
      //     },
      //     {
      //       "code": "+86",
      //       "name": "China"
      //     },
      //     {
      //       "code": "+61",
      //       "name": "Christmas Island"
      //     },
      //     {
      //       "code": "+61",
      //       "name": "Cocos-Keeling Islands"
      //     },
      //     {
      //       "code": "+57",
      //       "name": "Colombia"
      //     },
      //     {
      //       "code": "+269",
      //       "name": "Comoros"
      //     },
      //     {
      //       "code": "+242",
      //       "name": "Congo"
      //     },
      //     {
      //       "code": "+243",
      //       "name": "Congo, Dem. Rep. of (Zaire)"
      //     },
      //     {
      //       "code": "+682",
      //       "name": "Cook Islands"
      //     },
      //     {
      //       "code": "+506",
      //       "name": "Costa Rica"
      //     },
      //     {
      //       "code": "+385",
      //       "name": "Croatia"
      //     },
      //     {
      //       "code": "+53",
      //       "name": "Cuba"
      //     },
      //     {
      //       "code": "+599",
      //       "name": "Curacao"
      //     },
      //     {
      //       "code": "+537",
      //       "name": "Cyprus"
      //     },
      //     {
      //       "code": "+420",
      //       "name": "Czech Republic"
      //     },
      //     {
      //       "code": "+45",
      //       "name": "Denmark"
      //     },
      //     {
      //       "code": "+246",
      //       "name": "Diego Garcia"
      //     },
      //     {
      //       "code": "+253",
      //       "name": "Djibouti"
      //     },
      //     {
      //       "code": "+1 767",
      //       "name": "Dominica"
      //     },
      //     {
      //       "code": "+1 809",
      //       "name": "Dominican Republic"
      //     },
      //     {
      //       "code": "+670",
      //       "name": "East Timor"
      //     },
      //     {
      //       "code": "+56",
      //       "name": "Easter Island"
      //     },
      //     {
      //       "code": "+593",
      //       "name": "Ecuador"
      //     },
      //     {
      //       "code": "+20",
      //       "name": "Egypt"
      //     },
      //     {
      //       "code": "+503",
      //       "name": "El Salvador"
      //     },
      //     {
      //       "code": "+240",
      //       "name": "Equatorial Guinea"
      //     },
      //     {
      //       "code": "+291",
      //       "name": "Eritrea"
      //     },
      //     {
      //       "code": "+372",
      //       "name": "Estonia"
      //     },
      //     {
      //       "code": "+251",
      //       "name": "Ethiopia"
      //     },
      //     {
      //       "code": "+500",
      //       "name": "Falkland Islands"
      //     },
      //     {
      //       "code": "+298",
      //       "name": "Faroe Islands"
      //     },
      //     {
      //       "code": "+679",
      //       "name": "Fiji"
      //     },
      //     {
      //       "code": "+358",
      //       "name": "Finland"
      //     },
      //     {
      //       "code": "+33",
      //       "name": "France"
      //     },
      //     {
      //       "code": "+596",
      //       "name": "French Antilles"
      //     },
      //     {
      //       "code": "+594",
      //       "name": "French Guiana"
      //     },
      //     {
      //       "code": "+689",
      //       "name": "French Polynesia"
      //     },
      //     {
      //       "code": "+241",
      //       "name": "Gabon"
      //     },
      //     {
      //       "code": "+220",
      //       "name": "Gambia"
      //     },
      //     {
      //       "code": "+995",
      //       "name": "Georgia"
      //     },
      //     {
      //       "code": "+49",
      //       "name": "Germany"
      //     },
      //     {
      //       "code": "+233",
      //       "name": "Ghana"
      //     },
      //     {
      //       "code": "+350",
      //       "name": "Gibraltar"
      //     },
      //     {
      //       "code": "+30",
      //       "name": "Greece"
      //     },
      //     {
      //       "code": "+299",
      //       "name": "Greenland"
      //     },
      //     {
      //       "code": "+1 473",
      //       "name": "Grenada"
      //     },
      //     {
      //       "code": "+590",
      //       "name": "Guadeloupe"
      //     },
      //     {
      //       "code": "+1 671",
      //       "name": "Guam"
      //     },
      //     {
      //       "code": "+502",
      //       "name": "Guatemala"
      //     },
      //     {
      //       "code": "+224",
      //       "name": "Guinea"
      //     },
      //     {
      //       "code": "+245",
      //       "name": "Guinea-Bissau"
      //     },
      //     {
      //       "code": "+595",
      //       "name": "Guyana"
      //     },
      //     {
      //       "code": "+509",
      //       "name": "Haiti"
      //     },
      //     {
      //       "code": "+504",
      //       "name": "Honduras"
      //     },
      //     {
      //       "code": "+852",
      //       "name": "Hong Kong SAR China"
      //     },
      //     {
      //       "code": "+36",
      //       "name": "Hungary"
      //     },
      //     {
      //       "code": "+354",
      //       "name": "Iceland"
      //     },
      //     {
      //       "code": "+91",
      //       "name": "India"
      //     },
      //     {
      //       "code": "+62",
      //       "name": "Indonesia"
      //     },
      //     {
      //       "code": "+98",
      //       "name": "Iran"
      //     },
      //     {
      //       "code": "+964",
      //       "name": "Iraq"
      //     },
      //     {
      //       "code": "+353",
      //       "name": "Ireland"
      //     },
      //     {
      //       "code": "+972",
      //       "name": "Israel"
      //     },
      //     {
      //       "code": "+39",
      //       "name": "Italy"
      //     },
      //     {
      //       "code": "+225",
      //       "name": "Ivory Coast"
      //     },
      //     {
      //       "code": "+1 876",
      //       "name": "Jamaica"
      //     },
      //     {
      //       "code": "+81",
      //       "name": "Japan"
      //     },
      //     {
      //       "code": "+962",
      //       "name": "Jordan"
      //     },
      //     {
      //       "code": "+7 7",
      //       "name": "Kazakhstan"
      //     },
      //     {
      //       "code": "+254",
      //       "name": "Kenya"
      //     },
      //     {
      //       "code": "+686",
      //       "name": "Kiribati"
      //     },
      //     {
      //       "code": "+965",
      //       "name": "Kuwait"
      //     },
      //     {
      //       "code": "+996",
      //       "name": "Kyrgyzstan"
      //     },
      //     {
      //       "code": "+856",
      //       "name": "Laos"
      //     },
      //     {
      //       "code": "+371",
      //       "name": "Latvia"
      //     },
      //     {
      //       "code": "+961",
      //       "name": "Lebanon"
      //     },
      //     {
      //       "code": "+266",
      //       "name": "Lesotho"
      //     },
      //     {
      //       "code": "+231",
      //       "name": "Liberia"
      //     },
      //     {
      //       "code": "+218",
      //       "name": "Libya"
      //     },
      //     {
      //       "code": "+423",
      //       "name": "Liechtenstein"
      //     },
      //     {
      //       "code": "+370",
      //       "name": "Lithuania"
      //     },
      //     {
      //       "code": "+352",
      //       "name": "Luxembourg"
      //     },
      //     {
      //       "code": "+853",
      //       "name": "Macau SAR China"
      //     },
      //     {
      //       "code": "+389",
      //       "name": "Macedonia"
      //     },
      //     {
      //       "code": "+261",
      //       "name": "Madagascar"
      //     },
      //     {
      //       "code": "+265",
      //       "name": "Malawi"
      //     },
      //     {
      //       "code": "+60",
      //       "name": "Malaysia"
      //     },
      //     {
      //       "code": "+960",
      //       "name": "Maldives"
      //     },
      //     {
      //       "code": "+223",
      //       "name": "Mali"
      //     },
      //     {
      //       "code": "+356",
      //       "name": "Malta"
      //     },
      //     {
      //       "code": "+692",
      //       "name": "Marshall Islands"
      //     },
      //     {
      //       "code": "+596",
      //       "name": "Martinique"
      //     },
      //     {
      //       "code": "+222",
      //       "name": "Mauritania"
      //     },
      //     {
      //       "code": "+230",
      //       "name": "Mauritius"
      //     },
      //     {
      //       "code": "+262",
      //       "name": "Mayotte"
      //     },
      //     {
      //       "code": "+52",
      //       "name": "Mexico"
      //     },
      //     {
      //       "code": "+691",
      //       "name": "Micronesia"
      //     },
      //     {
      //       "code": "+1 808",
      //       "name": "Midway Island"
      //     },
      //     {
      //       "code": "+373",
      //       "name": "Moldova"
      //     },
      //     {
      //       "code": "+377",
      //       "name": "Monaco"
      //     },
      //     {
      //       "code": "+976",
      //       "name": "Mongolia"
      //     },
      //     {
      //       "code": "+382",
      //       "name": "Montenegro"
      //     },
      //     {
      //       "code": "+1664",
      //       "name": "Montserrat"
      //     },
      //     {
      //       "code": "+212",
      //       "name": "Morocco"
      //     },
      //     {
      //       "code": "+95",
      //       "name": "Myanmar"
      //     },
      //     {
      //       "code": "+264",
      //       "name": "Namibia"
      //     },
      //     {
      //       "code": "+674",
      //       "name": "Nauru"
      //     },
      //     {
      //       "code": "+977",
      //       "name": "Nepal"
      //     },
      //     {
      //       "code": "+31",
      //       "name": "Netherlands"
      //     },
      //     {
      //       "code": "+599",
      //       "name": "Netherlands Antilles"
      //     },
      //     {
      //       "code": "+1 869",
      //       "name": "Nevis"
      //     },
      //     {
      //       "code": "+687",
      //       "name": "New Caledonia"
      //     },
      //     {
      //       "code": "+64",
      //       "name": "New Zealand"
      //     },
      //     {
      //       "code": "+505",
      //       "name": "Nicaragua"
      //     },
      //     {
      //       "code": "+227",
      //       "name": "Niger"
      //     },
      //     {
      //       "code": "+234",
      //       "name": "Nigeria"
      //     },
      //     {
      //       "code": "+683",
      //       "name": "Niue"
      //     },
      //     {
      //       "code": "+672",
      //       "name": "Norfolk Island"
      //     },
      //     {
      //       "code": "+850",
      //       "name": "North Korea"
      //     },
      //     {
      //       "code": "+1 670",
      //       "name": "Northern Mariana Islands"
      //     },
      //     {
      //       "code": "+47",
      //       "name": "Norway"
      //     },
      //     {
      //       "code": "+968",
      //       "name": "Oman"
      //     },
      //     {
      //       "code": "+92",
      //       "name": "Pakistan"
      //     },
      //     {
      //       "code": "+680",
      //       "name": "Palau"
      //     },
      //     {
      //       "code": "+970",
      //       "name": "Palestinian Territory"
      //     },
      //     {
      //       "code": "+507",
      //       "name": "Panama"
      //     },
      //     {
      //       "code": "+675",
      //       "name": "Papua New Guinea"
      //     },
      //     {
      //       "code": "+595",
      //       "name": "Paraguay"
      //     },
      //     {
      //       "code": "+51",
      //       "name": "Peru"
      //     },
      //     {
      //       "code": "+63",
      //       "name": "Philippines"
      //     },
      //     {
      //       "code": "+48",
      //       "name": "Poland"
      //     },
      //     {
      //       "code": "+351",
      //       "name": "Portugal"
      //     },
      //     {
      //       "code": "+1 787",
      //       "name": "Puerto Rico"
      //     },
      //     {
      //       "code": "+974",
      //       "name": "Qatar"
      //     },
      //     {
      //       "code": "+262",
      //       "name": "Reunion"
      //     },
      //     {
      //       "code": "+40",
      //       "name": "Romania"
      //     },
      //     {
      //       "code": "+7",
      //       "name": "Russia"
      //     },
      //     {
      //       "code": "+250",
      //       "name": "Rwanda"
      //     },
      //     {
      //       "code": "+685",
      //       "name": "Samoa"
      //     },
      //     {
      //       "code": "+378",
      //       "name": "San Marino"
      //     },
      //     {
      //       "code": "+966",
      //       "name": "Saudi Arabia"
      //     },
      //     {
      //       "code": "+221",
      //       "name": "Senegal"
      //     },
      //     {
      //       "code": "+381",
      //       "name": "Serbia"
      //     },
      //     {
      //       "code": "+248",
      //       "name": "Seychelles"
      //     },
      //     {
      //       "code": "+232",
      //       "name": "Sierra Leone"
      //     },
      //     {
      //       "code": "+65",
      //       "name": "Singapore"
      //     },
      //     {
      //       "code": "+421",
      //       "name": "Slovakia"
      //     },
      //     {
      //       "code": "+386",
      //       "name": "Slovenia"
      //     },
      //     {
      //       "code": "+677",
      //       "name": "Solomon Islands"
      //     },
      //     {
      //       "code": "+27",
      //       "name": "South Africa"
      //     },
      //     {
      //       "code": "+500",
      //       "name": "South Georgia and the South Sandwich Islands"
      //     },
      //     {
      //       "code": "+82",
      //       "name": "South Korea"
      //     },
      //     {
      //       "code": "+34",
      //       "name": "Spain"
      //     },
      //     {
      //       "code": "+94",
      //       "name": "Sri Lanka"
      //     },
      //     {
      //       "code": "+249",
      //       "name": "Sudan"
      //     },
      //     {
      //       "code": "+597",
      //       "name": "Suriname"
      //     },
      //     {
      //       "code": "+268",
      //       "name": "Swaziland"
      //     },
      //     {
      //       "code": "+46",
      //       "name": "Sweden"
      //     },
      //     {
      //       "code": "+41",
      //       "name": "Switzerland"
      //     },
      //     {
      //       "code": "+963",
      //       "name": "Syria"
      //     },
      //     {
      //       "code": "+886",
      //       "name": "Taiwan"
      //     },
      //     {
      //       "code": "+992",
      //       "name": "Tajikistan"
      //     },
      //     {
      //       "code": "+255",
      //       "name": "Tanzania"
      //     },
      //     {
      //       "code": "+66",
      //       "name": "Thailand"
      //     },
      //     {
      //       "code": "+670",
      //       "name": "Timor Leste"
      //     },
      //     {
      //       "code": "+228",
      //       "name": "Togo"
      //     },
      //     {
      //       "code": "+690",
      //       "name": "Tokelau"
      //     },
      //     {
      //       "code": "+676",
      //       "name": "Tonga"
      //     },
      //     {
      //       "code": "+1 868",
      //       "name": "Trinidad and Tobago"
      //     },
      //     {
      //       "code": "+216",
      //       "name": "Tunisia"
      //     },
      //     {
      //       "code": "+90",
      //       "name": "Turkey"
      //     },
      //     {
      //       "code": "+993",
      //       "name": "Turkmenistan"
      //     },
      //     {
      //       "code": "+1 649",
      //       "name": "Turks and Caicos Islands"
      //     },
      //     {
      //       "code": "+688",
      //       "name": "Tuvalu"
      //     },
      //     {
      //       "code": "+1 340",
      //       "name": "U.S. Virgin Islands"
      //     },
      //     {
      //       "code": "+256",
      //       "name": "Uganda"
      //     },
      //     {
      //       "code": "+380",
      //       "name": "Ukraine"
      //     },
      //     {
      //       "code": "+971",
      //       "name": "United Arab Emirates"
      //     },
      //     {
      //       "code": "+44",
      //       "name": "United Kingdom"
      //     },
      //     {
      //       "code": "+1",
      //       "name": "United States"
      //     },
      //     {
      //       "code": "+598",
      //       "name": "Uruguay"
      //     },
      //     {
      //       "code": "+998",
      //       "name": "Uzbekistan"
      //     },
      //     {
      //       "code": "+678",
      //       "name": "Vanuatu"
      //     },
      //     {
      //       "code": "+58",
      //       "name": "Venezuela"
      //     },
      //     {
      //       "code": "+84",
      //       "name": "Vietnam"
      //     },
      //     {
      //       "code": "+1 808",
      //       "name": "Wake Island"
      //     },
      //     {
      //       "code": "+681",
      //       "name": "Wallis and Futuna"
      //     },
      //     {
      //       "code": "+967",
      //       "name": "Yemen"
      //     },
      //     {
      //       "code": "+260",
      //       "name": "Zambia"
      //     },
      //     {
      //       "code": "+255",
      //       "name": "Zanzibar"
      //     },
      //     {
      //       "code": "+263",
      //       "name": "Zimbabwe"
      //     }
      //   ]
      // }

      /***/
    },

    /***/
    "mqhL":
    /*!**************************************************!*\
      !*** ./src/app/services/practitioner.service.ts ***!
      \**************************************************/

    /*! exports provided: PractitionerService */

    /***/
    function mqhL(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PractitionerService", function () {
        return PractitionerService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_fire_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/fire/storage */
      "Vaw3");
      /* harmony import */


      var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/fire/firestore */
      "I/3d");

      var PractitionerService = /*#__PURE__*/function () {
        function PractitionerService(storage, fireStore) {
          _classCallCheck(this, PractitionerService);

          this.storage = storage;
          this.fireStore = fireStore; // loading sub

          this.loading = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](false); // values of applicant data

          this.certificateNames = [];
          this.title = "";
          this.practitionerFirstName = "";
          this.practitionerLastName = "";
          this.email = "";
          this.about = "";
          this.education = "";
          this.experience = "";
          this.gender = "";
          this.phone = "";
          this.countryCode = "";
          this.specialty = "";
          this.subCategory = "";
          this.pricePerSession = 0;
          this.lat = 0;
          this.longt = 0;
          this.locationDescription = "";
          this.rating = 0;
          this.practitionerId = "";
          this.locationName = "";
          this.languages = "";
          this.imagePath = "";
        } // uplaod applicant to firestore


        _createClass(PractitionerService, [{
          key: "uploadApplicant",
          value: function uploadApplicant() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              var _this8 = this;

              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      _context4.prev = 0;
                      _context4.next = 3;
                      return this.fireStore.collection("Applicants").add({
                        title: this.title,
                        practitionerFirstName: this.practitionerFirstName,
                        practitionerLastName: this.practitionerLastName,
                        gender: this.gender,
                        email: this.email,
                        phone: this.phone,
                        countryCode: this.countryCode,
                        specialty: this.specialty,
                        subCategory: this.subCategory,
                        experience: this.experience,
                        education: this.education,
                        about: this.about,
                        pricePerSession: this.pricePerSession,
                        languages: this.languages,
                        certificates: this.certificateNames,
                        lat: this.lat,
                        longt: this.longt,
                        locationName: this.locationName,
                        id: "",
                        imagePath: this.imagePath
                      }).then(function (res) {
                        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this8, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                          return regeneratorRuntime.wrap(function _callee3$(_context3) {
                            while (1) {
                              switch (_context3.prev = _context3.next) {
                                case 0:
                                  console.log("the result from Firebase", res.id); // set the image path

                                  this.imagePath = res.id + ".jpg"; // update the id and image path of the applicant

                                  _context3.next = 4;
                                  return this.fireStore.collection("Applicants").doc(res.id).update({
                                    id: res.id,
                                    imagePath: this.imagePath
                                  });

                                case 4:
                                case "end":
                                  return _context3.stop();
                              }
                            }
                          }, _callee3, this);
                        }));
                      }).then(function (res) {
                        console.log("result formt the update", res); // upload the applicant image

                        _this8.uploadPractitionerImage();
                      });

                    case 3:
                      _context4.next = 8;
                      break;

                    case 5:
                      _context4.prev = 5;
                      _context4.t0 = _context4["catch"](0);
                      console.log(_context4.t0);

                    case 8:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this, [[0, 5]]);
            }));
          } // upload applicant image implementation

        }, {
          key: "uploadPractitionerImage",
          value: function uploadPractitionerImage() {
            var path = this.imagePath;

            try {
              this.task = this.storage.upload(this.imagePath, this.file);
            } catch (err) {}
          }
        }]);

        return PractitionerService;
      }();

      PractitionerService.ɵfac = function PractitionerService_Factory(t) {
        return new (t || PractitionerService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_fire_storage__WEBPACK_IMPORTED_MODULE_3__["AngularFireStorage"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_4__["AngularFirestore"]));
      };

      PractitionerService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
        token: PractitionerService,
        factory: PractitionerService.ɵfac,
        providedIn: "root"
      });
      /***/
    },

    /***/
    "vY5A":
    /*!***************************************!*\
      !*** ./src/app/app-routing.module.ts ***!
      \***************************************/

    /*! exports provided: AppRoutingModule */

    /***/
    function vY5A(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
        return AppRoutingModule;
      });
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _screens_register_practitioner_register_practitioner_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./screens/register-practitioner/register-practitioner.component */
      "95/t");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var routes = [{
        path: '',
        component: _screens_register_practitioner_register_practitioner_component__WEBPACK_IMPORTED_MODULE_1__["RegisterPractitionerComponent"]
      }];

      var AppRoutingModule = function AppRoutingModule() {
        _classCallCheck(this, AppRoutingModule);
      };

      AppRoutingModule.ɵfac = function AppRoutingModule_Factory(t) {
        return new (t || AppRoutingModule)();
      };

      AppRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({
        type: AppRoutingModule
      });
      AppRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
        imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forRoot(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]]
      });

      (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](AppRoutingModule, {
          imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]],
          exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]]
        });
      })();
      /***/

    },

    /***/
    "zUnb":
    /*!*********************!*\
      !*** ./src/main.ts ***!
      \*********************/

    /*! no exports provided */

    /***/
    function zUnb(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/platform-browser */
      "jhN1");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./app/app.module */
      "ZAI4");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./environments/environment */
      "AytR");

      if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
      }

      _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])["catch"](function (err) {
        return console.error(err);
      });
      /***/

    },

    /***/
    "zn8P":
    /*!******************************************************!*\
      !*** ./$$_lazy_route_resource lazy namespace object ***!
      \******************************************************/

    /*! no static exports found */

    /***/
    function zn8P(module, exports) {
      function webpackEmptyAsyncContext(req) {
        // Here Promise.resolve().then() is used instead of new Promise() to prevent
        // uncaught exception popping up in devtools
        return Promise.resolve().then(function () {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        });
      }

      webpackEmptyAsyncContext.keys = function () {
        return [];
      };

      webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
      module.exports = webpackEmptyAsyncContext;
      webpackEmptyAsyncContext.id = "zn8P";
      /***/
    }
  }, [[0, "runtime", "vendor"]]]);
})();
//# sourceMappingURL=main-es5.js.map